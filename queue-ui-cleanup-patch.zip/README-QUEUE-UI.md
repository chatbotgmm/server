# Queue screen cleanup v3.3 — separate client-only patch

This patch follows the unchanged, CI-tested casual AI v3.2 bundle. Keep both existing ZIPs unchanged. Add queue-ui-cleanup-patch.zip and use the accompanying full workflow only when ready to validate this optional client update.

Five files change: native controller and its tests, web queue controller/screen and tests. No server logic, API contract, database schema, rating or item rules change.

- Removes the manual status-recheck button and long matchmaking-policy paragraph.
- Uses a compact waiting screen with short rotating messages and a lightweight flourish.
- Shows elapsed matchmaking time only after the server acknowledges a WAITING ticket with its queue timestamp. A rejected request no longer appears to be searching.
- Keeps cancellation authoritative and preserves known tickets on ambiguous network outcomes.
- Uses bounded automatic transport recovery with backoff; input/version validation errors stop rather than retrying indefinitely. Protocol is never downgraded.

## Apply only to a disposable generated v3.2 checkout

After all existing generators and apply-casual-ai.py --apply, extract this ZIP without overwriting existing files. Run python3 apply-queue-ui-cleanup.py for dry-run, then the same command with --apply. For a separate worktree pass --root /path/to/repository-root. All five expected source hashes must match before any write; backups are exclusive and exact reapplication is idempotent.

The ongoing v3.2 backend deployment must remain pinned to its tested commit and hashes. This patch does not fix an old backend rejecting protocol 3; matching v3.2 backend deployment is still required. Install the newly tested APK only after this separate CI succeeds. Updated web assets require a later controlled release; do not overwrite the running release in place.

No database migration, reset, production operation or automatic deployment is included. See VERIFICATION-QUEUE-UI.md for actual verification and limits.
