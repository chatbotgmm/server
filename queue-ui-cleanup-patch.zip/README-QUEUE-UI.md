# Queue UI v3.4: tap-only waiting messages

Replace the repository-root queue-ui-cleanup-patch.zip and .github/workflows/casual-ai-preview.yml. Keep realtime-ranked-bundle.zip and casual-ai-fallback-patch.zip unchanged. This replacement includes the earlier v3.3 cleanup and applies directly after the generated v3.2 sources; it does not require applying v3.3 first.

The waiting message never advances automatically. Tap/click the message to advance it; no popup opens. Timer ticks and server polling preserve the selected message. Elapsed matchmaking time still updates only when the server confirms a waiting ticket. Cancellation, network recovery, acceptance, preparation and battle behavior remain unchanged.

Six source files are included: Android controller/tests, web controller/screen/tests, and a new focused screen test. No backend logic, API, database schema, inventory, rating or score reset changes.

## Disposable source application

After the existing generators and apply-casual-ai.py --apply, safely extract this ZIP. Run python3 apply-queue-ui-cleanup.py for validation, then add --apply. Use --root /path/to/repository-root when needed. The installer validates every expected v3.2 source hash before writing, requires the new test path to be absent, creates exclusive backups, and accepts an exact already-applied result. Different existing content or partial application stops the patch.

Use the new APK only after this workflow's Android tests and APK build pass. The deployed v3.2 backend is compatible. Website changes require a separately reviewed static bundle deployment; uploading these files to GitHub does not deploy the website. No reset, migration or automatic deployment is included.
