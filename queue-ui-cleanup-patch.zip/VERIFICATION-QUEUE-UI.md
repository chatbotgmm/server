# Queue UI v3.3 verification

This is a separate five-file client patch atop the unchanged v3.2 payload. The v3.2 backend was already validated by CI run 39032908440 at commit 5251165da9426b3b49fa848e1803d6e06d743721: 389 server tests passed; native 212 passed, 16 existing skips, zero failures. Those results do not claim the new v3.3 native tests have run.

## Local final results

TypeScript and npm build passed. Final `TOKIO_WORKER_THREADS=2 node scripts/test-db.mjs` run passed all 400 tests across 27 files in 30.16 seconds. All three packaged web files match tested source hashes; server source remains unchanged.

## Client changes

Native tests expand from 19 to 24; web tests add 11 regressions. Coverage includes rejected-input state without misleading wait time, authoritative elapsed time, bounded transport retries, cancellation acknowledgment, paused retry resumption/account refresh, and terminal destruction ignoring delayed replies/lifecycle restarts. Existing recovery/authentication/cancellation assertions remain.

Independent source review identified and resolved two web issues before packaging: missing authoritative timestamps no longer show a local counter; destroyed controllers invalidate pending responses and cannot restart through page lifecycle listeners. Native queue retry/account/background logic was reviewed. Existing in-battle room polling behavior is unchanged and remains outside this queue-only patch.

Local testing uses the isolated pinned artifact workspace, synthetic accounts and fresh temporary SQLite databases, never production configuration or data. Artwork placeholders test file presence only, not appearance. Android SDK/Gradle runtime is unavailable locally, so native compilation and all 24 NativeRealtime tests must run in the supplied CI workflow before APK use. Instrumentation/device visual tests remain separate.

The installer validates exact v3.2 source hashes for all five files, writes exclusive backups, and supports exact idempotent reapplication. Existing v3.2 backend ZIP/hash is retained in both CI jobs; the new client-only ZIP is applied afterward. No database schema, migration, reset or production deployment is included.
