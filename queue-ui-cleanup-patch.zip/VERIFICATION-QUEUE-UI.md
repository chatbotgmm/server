# Queue UI v3.4 verification

This six-file client patch applies to generated v3.2 source, retaining its backend unchanged. Prior v3.3 CI run39082174777 passed400 server/web tests and217 Android tests with16 existing skips. Those prior results do not certify v3.4 Android behavior.

Final isolated verification: focused web tests48/48; TypeScript and npm build pass; constrained full database suite403/403 across28files. Tests use synthetic accounts and temporary SQLite, with no production configuration or data. Artwork placeholders validate routes/file presence only.

NativeRealtime tests increase from24 to27. New tests cover no timed text rotation, tap progression without a popup, preserving the selected phrase across polls, and inert clicks in error state. Android SDK/runtime is unavailable locally: all27 native tests and APK compilation must pass the supplied GitHub workflow before release.

Three new web presentation tests use a clock-driven elapsed-time stub, advancing through8/60seconds and after tapping. They verify no automatic rotation, tap progression and wraparound, poll preservation, updated accessible names, no API action, and ignored destroyed/detached buttons. Existing controller/network/cancellation tests remain unchanged.

The installer checks all payload hashes, expected v3.2 baselines, new-file absence, exclusive backups, and exact reapplication. A conflicting new test file fails closed. Both CI jobs retain the original two ZIP hashes and apply this third ZIP afterward. No server logic, migration, reset or automatic deployment is included.
