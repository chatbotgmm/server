import hashlib,json,shutil,subprocess,sys,tempfile,unittest
from pathlib import Path
SCRIPT=Path(__file__).with_name('apply_rebuild.py')
def digest(data): return hashlib.sha256(data).hexdigest()
class InstallerTests(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name)
  self.bundle=self.root/'bundle';self.bundle.mkdir();shutil.copy2(SCRIPT,self.bundle/SCRIPT.name)
  self.project=self.root/'project';self.project.mkdir();(self.project/'package.json').write_text('{}')
  (self.project/'old.txt').write_bytes(b'old')
  self.entries=[]
  for name,before,after in [('old.txt',b'old',b'updated'),('new.txt',None,b'new')]:
   payload=self.bundle/'payload'/name;payload.parent.mkdir(parents=True,exist_ok=True);payload.write_bytes(after)
   self.entries.append(dict(path=name,before_sha256=digest(before) if before else None,after_sha256=digest(after)))
  self.manifest()
 def manifest(self): (self.bundle/'patch-manifest.json').write_text(json.dumps({'files':self.entries}))
 def tearDown(self): self.temp.cleanup()
 def run_patch(self,apply=False):
  return subprocess.run([sys.executable,str(self.bundle/SCRIPT.name),'--project',str(self.project)]+(['--apply'] if apply else []),capture_output=True,text=True)
 def test_default_readonly(self):
  self.assertEqual(self.run_patch().returncode,0);self.assertEqual((self.project/'old.txt').read_bytes(),b'old');self.assertFalse((self.project/'new.txt').exists())
 def test_apply_backup_idempotence(self):
  self.assertEqual(self.run_patch(True).returncode,0);self.assertEqual((self.project/'old.txt').read_bytes(),b'updated');self.assertEqual((self.project/'new.txt').read_bytes(),b'new')
  backups=list((self.project/'.gmm-rebuild-backups').glob('*/old.txt'));self.assertEqual(len(backups),1);self.assertEqual(backups[0].read_bytes(),b'old')
  self.assertEqual(self.run_patch(True).returncode,0);self.assertEqual(len(list((self.project/'.gmm-rebuild-backups').iterdir())),1)
 def test_wrong_baseline_no_partial_write(self):
  (self.project/'new.txt').write_bytes(b'foreign');self.assertNotEqual(self.run_patch(True).returncode,0);self.assertEqual((self.project/'old.txt').read_bytes(),b'old')
 def test_corrupt_payload_no_write(self):
  (self.bundle/'payload/new.txt').write_bytes(b'corrupt');self.assertNotEqual(self.run_patch(True).returncode,0);self.assertEqual((self.project/'old.txt').read_bytes(),b'old')
 def test_traversal_rejected(self):
  self.entries[1]['path']='../escape.txt';self.manifest();self.assertNotEqual(self.run_patch(True).returncode,0);self.assertEqual((self.project/'old.txt').read_bytes(),b'old')
 def test_symlink_rejected(self):
  external=self.root/'external';external.write_bytes(b'old');(self.project/'old.txt').unlink();(self.project/'old.txt').symlink_to(external)
  self.assertNotEqual(self.run_patch(True).returncode,0);self.assertEqual(external.read_bytes(),b'old')
if __name__=='__main__': unittest.main()
