#!/usr/bin/env python3
"""Checksum-guarded source patch. Defaults to validation, never deploys."""
import argparse, hashlib, json, shutil, sys
from datetime import datetime, timezone
from pathlib import Path

BASE = Path(__file__).resolve().parent

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def child(root, name):
    rel = Path(name)
    if rel.is_absolute() or '..' in rel.parts or not rel.parts:
        raise ValueError('Unsafe manifest path: ' + name)
    path = root / rel
    if not path.resolve().is_relative_to(root.resolve()):
        raise ValueError('Path escapes root: ' + name)
    if path.is_symlink():
        raise ValueError('Symlink target refused: ' + name)
    return path

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--project', required=True, type=Path, help='galmaegiman-confirmed project root')
    p.add_argument('--apply', action='store_true', help='Apply only after ALL checks pass')
    args = p.parse_args()
    root = args.project.resolve()
    manifest = json.loads((BASE / 'patch-manifest.json').read_text())
    if not (root / 'package.json').is_file():
        raise ValueError('Project root must contain package.json')
    changes = []
    for entry in manifest['files']:
        target = child(root, entry['path'])
        payload = child(BASE / 'payload', entry['path'])
        if not payload.is_file() or sha(payload) != entry['after_sha256']:
            raise ValueError('Payload checksum mismatch: ' + entry['path'])
        current = sha(target) if target.is_file() else None
        if target.exists() and not target.is_file():
            raise ValueError('Non-file target: ' + entry['path'])
        if current == entry['after_sha256']:
            continue
        if current != entry['before_sha256']:
            raise ValueError('Baseline mismatch; NOTHING applied: ' + entry['path'])
        changes.append((entry, target, payload))
    print('Validated %d files; %d changes required.' % (len(manifest['files']), len(changes)))
    if not args.apply:
        print('CHECK ONLY. Review provenance and tests before adding --apply.')
        return
    if not changes:
        print('Already applied.')
        return
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ')
    backup = root / '.gmm-rebuild-backups' / stamp
    backup.mkdir(parents=True, exist_ok=False)
    completed = []
    try:
        for entry, target, payload in changes:
            if target.exists():
                dest = child(backup, entry['path'])
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(target, dest)
            target.parent.mkdir(parents=True, exist_ok=True)
            completed.append((entry, target))
            shutil.copy2(payload, target)
        (backup / 'applied-manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2))
    except Exception:
        for entry, target in reversed(completed):
            previous = child(backup, entry['path'])
            if previous.exists():
                shutil.copy2(previous, target)
            elif target.exists():
                target.unlink()
        raise
    print('Patch applied. Backup:', backup)
    print('No build, migration, service restart, signing, push or deployment was performed.')

if __name__ == '__main__':
    try:
        main()
    except (ValueError, OSError, KeyError) as exc:
        print('STOP:', exc, file=sys.stderr)
        sys.exit(2)
