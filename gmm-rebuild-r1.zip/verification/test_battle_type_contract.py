"""Source-contract checks; does not substitute Android UI/device execution."""
from pathlib import Path
import unittest, json, hashlib, subprocess, tempfile
ROOT=Path(__file__).resolve().parents[1]
JAVA=ROOT/'source/app/android/app/src/main/java/org/dpdns/gmm'
S=(JAVA/'BattleTypeInfo.java').read_text()
class TypeContract(unittest.TestCase):
 def test_character_defense(self):
  self.assertIn('showFighter(this,target)',(JAVA/'BattleView.java').read_text())
  self.assertIn('boolean defense=skill==null',S)
  self.assertIn('matchup.optJSONObject("defense")',S)
 def test_skill_attack(self):
  self.assertIn('show(v, skillAttr(v, skill), skill, null)',S)
  self.assertIn('skill.optJSONObject("preview")',S)
 def test_ten_actual_icons(self):
  icons=(JAVA/'JournalIcons.java').read_text()
  for name in ['stone','gold','fire','ice','blossom','sea','shadow','star','thread','gravity']:
   self.assertIn('"'+name+'"',icons);self.assertIn('"'+name.upper()+'"',S)
 def test_authoritative_phase(self):
  for contract in ['!phaseId.equals(latest.optString("phaseId"))','!session.equals(latest.optString("roomId"))','turn!=current.optInt("turn")','!phase.equals(current.optString("phase"))','latest.optJSONObject("result")!=null','if(changed){dialog.dismiss();return;}']:
   self.assertIn(contract,S)
 def test_timer_own_input_and_monotonic(self):
  for contract in ['latest.optBoolean("canSubmit")','!latest.optBoolean("mySubmitted")','!realtime.writing','!realtime.playing','realtime.serverAtReceive+android.os.SystemClock.elapsedRealtime()-realtime.receivedElapsed','latest.optLong("deadline",0)']:
   self.assertIn(contract,S)
  self.assertNotIn('System.currentTimeMillis()',S)
 def test_cleanup(self):
  for contract in ['onViewDetachedFromWindow(android.view.View view){','v.removeCallbacks(tick[0])','v.removeOnAttachStateChangeListener(attachment)','closed[0]=true','dialog.setCanceledOnTouchOutside(true)','close.setOnClickListener(view->dialog.dismiss())']:
   self.assertIn(contract,S)
 def test_waiting_surrender_confirmation(self):
  view=(JAVA/'BattleView.java').read_text()
  realtime=(JAVA/'NativeRealtime.java').read_text()
  server=(ROOT/'source/src/pvp/service.ts').read_text()
  self.assertIn('&& !phase.equals("over") && !pane.equals("leave"))',view)
  self.assertIn('pane="leave"; render();',view)
  self.assertIn('case "leave":\n        surrenderPane();',view)
  self.assertIn('host.button("확인 · 나가기", () -> host.battleTurnFrom(battle, MainActivity.obj("leave", true)))',view)
  submit=realtime[realtime.index('  void submit('):realtime.index('  boolean freeSwitch(')]
  self.assertLess(submit.index('if (event.optBoolean("leave"))'),submit.index('if (!latest.optBoolean("canSubmit"))'))
  self.assertIn('!event.optBoolean("leave") && inputDeadline',submit)
  surrender=server[server.index('  async surrender('):server.index('  async rank(')]
  self.assertIn("'SURRENDER'",surrender)
  self.assertNotIn('canSubmit',surrender)
 def test_multiplier_pure_java(self):
  # Execute the exact pure formatter from production source with javac source launcher.
  start=S.index('  static String currentMultiplier(');end=S.index('\n  private static void show(',start)
  method=S[start:end]
  code='class MultiplierProbe {\n'+method+'''\npublic static void main(String[] args){
    if(!currentMultiplier(0,false).equals("무효 · ×0"))throw new AssertionError("zero");
    if(!currentMultiplier(0,true).equals("무효 · ×0"))throw new AssertionError("defense zero");
    if(!currentMultiplier(1.5,true).contains("취약"))throw new AssertionError("defense strong");
    if(!currentMultiplier(.5,true).contains("저항"))throw new AssertionError("defense weak");
    if(!currentMultiplier(1.5,false).contains("유리"))throw new AssertionError("attack strong");
    if(!currentMultiplier(Double.NaN,false).contains("정보 없음"))throw new AssertionError("unknown");
    System.out.println("6 exact-source multiplier checks passed");
  }}'''
  with tempfile.TemporaryDirectory() as tmp:
   f=Path(tmp)/'MultiplierProbe.java';f.write_text(code)
   subprocess.run(['java',str(f)],check=True)
if __name__=='__main__':unittest.main()
