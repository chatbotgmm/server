from pathlib import Path
import unittest
ROOT = Path(__file__).resolve().parents[1] / 'source/app/android/app/src/main/java/org/dpdns/gmm'
def read(name): return (ROOT/(name+'.java')).read_text()
class MenuContracts(unittest.TestCase):
 def test_fixed_split_has_no_overflow_wrapper(self):
  s=read('MenuKit').split('LinearLayout[] fixedSplit(')[1].split('void footer(')[0]
  self.assertNotIn('viewport(', s)
  self.assertNotIn('ScrollView', s)
  self.assertIn('new LinearLayout.LayoutParams(-1, 0, 1)',s)
 def test_team_primary_path_is_inline(self):
  s=read('NativeMenus').split('  void team() {')[1].split('  void teamPicker(')[0]
  self.assertIn('k.fixedSplit(.46f)',s)
  self.assertIn('team-inline-candidates',s)
  self.assertNotIn('teamPicker(',s)
  self.assertNotIn('openSheet(',s)
  self.assertIn('candidatePage[0] * 6 + row * 3 + column',s)
  self.assertIn('previous.setEnabled(candidatePage[0] > 0)',s)
  self.assertIn('next.setEnabled(candidatePage[0] < pageCount - 1)',s)
 def test_save_routes_and_draft_safety_preserved(self):
  s=read('NativeMenus')
  self.assertIn('pvp ? "battle-team" : "native/team"',s)
  self.assertIn('pvp ? "ids" : "keys"',s)
  self.assertIn('if (error != null) return;',s)
  self.assertIn('teamDraft.addAll(teamSavedIds)',s)
 def test_collection_fixed_paged_search(self):
  s=read('NativeLibrary').split('  void collection() {')[1].split('  TextView line(')[0]
  self.assertIn('k.fixedBody()',s)
  self.assertIn('collectionPage*8 + row*4 + col',s)
  self.assertIn('search.addTextChangedListener',s)
  self.assertIn('collectionOwned',s)
  self.assertNotIn('collectionPicker(',s)
  self.assertNotIn('k.scroll(',s)
 def test_augment_expiry_guards_all_actions(self):
  s=read('NativeAugmentView')
  self.assertEqual(s.count('if (!canChoose()) return;'),3) # select, reroll, replacement
  self.assertIn('if (!canChoose() || (switching ? switchTo < 0 : selected.isEmpty())) return;',s)
  self.assertIn('System.currentTimeMillis() + clockOffset < deadline',s)
  self.assertIn('confirm.setText("결과 확인 중")',s)
  self.assertIn('for (Button reroll : rerolls) reroll.setEnabled(false)',s)
  self.assertNotIn('void explain(',s)
  self.assertNotIn('"상세"',s)
 def test_augment_deadline_authority_unchanged(self):
  s=read('NativeAugmentView')
  self.assertEqual(s.count('deadline ='),1)
  self.assertIn('deadline = view.battle.optLong("chooseDeadline", 0)',s)
  self.assertIn('h.realtime.refresh()',s)
  self.assertIn('"native/battle/current"',s)
 def test_consequential_economy_confirmation_retained(self):
  s=read('NativeEconomy')
  self.assertIn('h.confirm(',s)
  self.assertIn('뽑기권 ',s)
 def test_shared_navy_brass_tokens(self):
  s=read('JournalTheme')
  for token in ['0xfff3e9d3','0xff20343a','0xff153f50','0xffbc9555','0xffdce8e6']:
   self.assertIn(token,s)
 def test_candidate_algorithm_preserves_uniqueness(self):
  # Exhaustive model of the exact inline assignment branches, not an Android UI test.
  import itertools
  for size in range(4):
   for draft0 in itertools.permutations('abcd',size):
    for slot in range(3):
     for key in 'abcd':
      draft=list(draft0); target=min(slot,len(draft)); old=draft.index(key) if key in draft else -1
      if old>=0 and old!=target and target<len(draft): draft[target],draft[old]=key,draft[target]
      elif old<0:
       if target<len(draft): draft[target]=key
       elif len(draft)<3: draft.append(key)
      self.assertLessEqual(len(draft),3)
      self.assertEqual(len(draft),len(set(draft)))
if __name__ == '__main__': unittest.main(verbosity=2)
