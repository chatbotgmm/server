# Casual actual-level patch

This patch targets a synthetic assembled test workspace, not a complete v81 production source tree. No production database, reset, seed script, deployment, network push, or schema migration was used.

## Changed source/test files
- src/pvp/service.ts: server-owned StorySave growth lookup, selected owned-instance keys, legacy species-key fallback, mode-specific roster preparation, AI recomputation after final lineup, one-time human combat compensation, casual-only rules version.
- src/pvp/casual-balance.ts (new): validation, deployed mean, saved-growth copy, matched AI generation and capped combat-stat boost helpers.
- test/casual-balance.test.ts (new): 22 helper tests.
- test/casual-growth.integration.test.ts (new): 5 real-service isolated SQLite tests; creates/disposes its own temporary DB, inserts test fixtures directly.
- test/realtime-casual-ai.integration.test.ts: one expected selectedIds assertion updated from species IDs to owned-instance IDs.

## Behavior
Casual uses the chosen owned copy's level, XP, promotion, augments and learned skills from StorySave. These are copied and never written by PvP. Missing growth uses the existing native story start level. Species-only legacy requests resolve the first matching eligible ownership row ordered by ID, never the strongest copy. Three distinct species remain required.

AI level is the rounded arithmetic mean of the actual final deployed team; AI is regenerated after preparation changes. It uses existing level-eligible promotion thresholds, stable evolution choices and innate skills, adding the existing promotion signature when promoted. No human compensation applies to AI games.

Human-only casual compensation is min(0.15, 0.25*(sqrt(strongerMean/weakerMean)-1)), applied once to weaker-side fresh combat HP, physical/magical attack and physical/magical defense. Integer stats floor after scaling so rounding cannot exceed the percentage cap. Speed, fighter scale, skill power and owned growth stay unchanged. Polls/reconnects deserialize the same compensated battle, without reapplying it.

Ranked retains fixed configured level, stage 0, original skill defaults, original rules hash, no compensation, and no AI fallback. Existing MMR, acceptance windows, queue leases, escrow and settlement code paths remain intact.

Casual available.id and selectedIds are now opaque o<owned id> keys. available also carries characterId, level, stage and the unchanged species image URL. Native worker confirmed opaque-key compatibility. Inspected web preparation code uses u.image for artwork and IDs opaquely; parent restored newer web baseline and is running its client tests.

## Verification
- node node_modules/vitest/vitest.mjs run test/casual-balance.test.ts test/casual-growth.integration.test.ts --maxWorkers=1: 27/27 passed.
- node node_modules/typescript/bin/tsc --noEmit -p tsconfig.json: passed before final casual/ranked version-hash isolation; parent repeats latest compile.
- node <evidence>/run-casual-regression.mjs from source directory: 88/88 passed across realtime-casual-ai, realtime-acceptance, realtime-pvp, item-escrow and ranked-settlement integration suites. Latest log is casual-regression.log. Runner never loads a production env file or calls prisma/seed.ts.

## Baseline and limitations
No Git checkout exists in the assembled workspace, so there is no truthful single baseline commit SHA for this service overlay. Its preserved source SHA256 is 74d924121f4b214143b820bd7414752f62a336dc5ae496da75b7f976fbd2bdc2. Workspace provenance references upstream restoration commit 0f00c9716f29ffec575d525db269d2de6b61a863, but the service is a later synthetic overlay. Guard patch application by original file hash.

Original service and modified existing test are preserved under baseline-files/. New files have no previous version.

This is source and test verification, not production deployment or full APK/v81 restoration. Synthetic art remains unsuitable as evidence of original visuals. Existing active casual rooms from the previous rules hash will safely abort at upgrade; drain them before rollout if uninterrupted play is required. Ranked rooms retain their prior rules hash. The existing shared realtimeLineup slot remains shared across normal/rank modes, so entering a ranked battle can replace a previously saved casual instance selection with species selection; next casual preparation exposes explicit copy selection again.
