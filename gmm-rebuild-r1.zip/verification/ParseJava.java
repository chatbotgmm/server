import java.nio.file.*;
import java.util.*;
import javax.tools.*;
import com.sun.source.util.JavacTask;
public class ParseJava {
 public static void main(String[] args) throws Exception {
  JavaCompiler compiler=ToolProvider.getSystemJavaCompiler();
  DiagnosticCollector<JavaFileObject> diagnostics=new DiagnosticCollector<>();
  try(StandardJavaFileManager manager=compiler.getStandardFileManager(diagnostics,null,null)) {
   List<java.io.File> files=new ArrayList<>();
   try(var stream=Files.walk(Path.of(args[0]))){stream.filter(p->p.toString().endsWith(".java")).forEach(p->files.add(p.toFile()));}
   JavacTask task=(JavacTask)compiler.getTask(null,manager,diagnostics,List.of("-proc:none"),null,manager.getJavaFileObjectsFromFiles(files));
   task.parse();
   for(var d:diagnostics.getDiagnostics()) if(d.getKind()==Diagnostic.Kind.ERROR)System.err.println(d);
   long errors=diagnostics.getDiagnostics().stream().filter(d->d.getKind()==Diagnostic.Kind.ERROR).count();
   System.out.println("Parsed "+files.size()+" Java files; syntax errors="+errors);
   if(errors>0)System.exit(1);
  }
 }
}
