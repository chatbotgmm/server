# Casual AI fallback v3.2 — manual source patch

Applies only after the previously reviewed realtime v2.2 generators. Keep the existing `realtime-ranked-bundle.zip` unchanged. This separate patch adds no database tables, migrations, point resets, accounts, credentials or deployment actions.

## v3.2 correction

The v3.1 server CI passed all 389 tests. One Android recovery test exposed a null queue view when replacing a controller while the host still remembered the queue screen. The queue now rebuilds whenever its own view references are absent. The existing recovery test additionally checks visible queue controls and enabled cancellation. No server, database or battle behavior changes in this revision.

## v3.1 correction

The first uploaded v3 CI passed 384 of 386 server tests. Concurrent SQLite transactions stalled in a constrained Prisma worker pool, causing two acceptance timeouts. This revision serializes realtime writers sharing one Prisma client before opening transactions, while retaining the database writer lock and full-transaction retries across clients/processes. No test timeout was increased. Two Android process-recovery tests also lacked their required logged-in player state; their fixture is corrected while keeping the production authentication guard and assertions unchanged.

Replace the existing casual-ai-fallback-patch.zip and the active casual-ai-preview.yml workflow with this revision. The original realtime-ranked-bundle.zip remains unchanged. Keep only one active preview workflow to avoid confusing older APKs with this build.

## Behavior

- Ranked, including promotion games, stays human-only forever.
- Casual queue attempts human matches first using its widening rating window. AI is permitted only when exactly one distinct active casual human remains waiting after human pairs have been formed. That person must have waited at least 30 seconds. Any other active casual human blocks AI, even outside the current MMR window.
- Active means an unexpired WAITING attempt with a matching unexpired QUEUE ownership record. Expired/disconnected leases and orphan records do not block fallback; ranked waiters and people merely online do not count. Population is measured after matched human pairs leave the queue in the same transaction. A lone leftover may receive AI in that same pass only if their own original wait already reached 30 seconds; matching other people does not reset that timer.
- Queue cancellation and matching share the existing database writer transaction. A completed cancellation cannot later create a room. If matching commits first, cancellation returns the existing matched room; it does not surrender it.
- The AI has no Player row, inventory, rating or client-authenticated side. Its name and room metadata identify it as AI. Human inventory and item costs still follow the existing escrow transaction.
- Every newly found match first has a server-authoritative 10-second accept/decline step. Both human acceptances are required before ranked registration or preparation. AI is explicitly labelled and already accepted. Decline/timeout has no LP/MMR/item penalty; only humans who had accepted return atomically to their original queue ticket. A late decline cancels that same returned ticket if still waiting, never forfeits a subsequent match.
- The human gets the same 30-second lineup preparation, then 30-second augment selection and simultaneous turn deadlines. AI preparation is already ready, so human Ready starts the augment phase immediately.
- AI commands are chosen from the phase-opening battle snapshot, committed privately before the human submits, and retained across polls, retries, rerolls and restarts. The existing deterministic battle AI chooses attacks. Forced replacements and augment choices are validated without applying them early.
- AI wins, losses, surrender and timeout do not change casual-human MMR/game counts, ranked matchmaking prior, ranked points/promotions, legacy points or human-vs-human settlement history. Human-vs-human behavior is unchanged.
- Three consecutive missed human action turns still forfeit. AI has no artificial timeout streak.

## Client compatibility

New queue attempts require protocol 3, supplied by the new native APK and updated web client. Older clients receive an explicit update-required message; legacy waiting requests are cancelled rather than entering a phase they cannot display. Already-started v2.2 battles can continue. Update the APK before starting a new match after backend deployment; refresh the web page to load the new client. The queue screen shows elapsed waiting time and a prominent cancel control, not a guaranteed countdown to AI.

## Apply source in a disposable checkout

1. Use the reviewed baseline/manual branch and apply the existing parchment, augment and realtime v2.2 generators in their existing order.
2. Verify the separate ZIP SHA-256 shown with the delivered file, then extract without overwriting existing files.
3. `python3 apply-casual-ai.py` validates all source and payload hashes without writing.
4. `python3 apply-casual-ai.py --apply` creates exclusive source backups and applies the patch.
5. Run the supplied complete CI workflow. Do not remove or skip existing tests.

The installer defaults to its own directory as repository root. For another worktree use `--root /path/to/worktree` (the directory containing `galmaegiman-confirmed`). It will stop on a different source version, existing backup, partially applied patch or unexpected files. Do not bypass these checks with broad replacement commands.

## Deployment safety

The currently deployed release is `/home/ubuntu/gmm-realtime-stage-J90p1T/galmaegiman-confirmed`; the original Git checkout's old update script is not the deployment path.

Build and validate a separate release first. Preserve the existing live `.env`, DB, config and download assets. Do not overwrite or rebuild the active release, run `db push`, seed, rerun point reset, or run the old update script for this patch. Stop the old service fully before starting the new release: mixed old/new workers do not understand AI rooms consistently. Existing human-room state remains compatible with the new code.

After AI rooms exist, do not roll back to v2.2 while they are active: drain them using the new release or keep maintenance while reviewing recovery. This patch does not itself restart services or modify any production data.

## Verification

See `VERIFICATION.md` for actual local test results, fixture limitations and pending GitHub/native/device checks. Local tests use synthetic accounts and fresh temporary SQLite databases, never production data or `.env`. End-to-end two-account device testing remains required after manual deployment.
