# Verification record — v3.1

All local execution used the isolated pinned v2.2 artifact workspace, official dependencies, synthetic accounts and temporary SQLite databases. No production `.env`, database or service was accessed.

## First uploaded v3 CI

Run 39027548971 at commit 6b41499e7e47d063f5d809f7b27e76fe232feeed verified both ZIP hashes and all source generation. Server build and diagnostics passed; full suite passed 384/386 with two 5-second acceptance timeouts. Native reported 228 tests: 210 passed, 16 existing skips, two new recovery-fixture failures. No new APK was uploaded.

## Corrections and validation

- Reproduced the transaction stall with two Prisma engine workers and five connections: 25 original duplicate-accept batches took 5040–5060ms each. The corrected per-client FIFO completed the same batches in 13–26ms.
- Database writer locking and full-transaction retries remain unchanged. No test timeout was raised and no assertion or test was skipped.
- Three new regressions cover repeated duplicate acceptance, multiple service instances sharing one Prisma client, and queue release after rejected validation.
- Normal full server suite: 389/389 tests passed across 27 files. TypeScript and server build passed.
- Full constrained suite (`TOKIO_WORKER_THREADS=2 node scripts/test-db.mjs`): 389/389 tests across 27 files, 28.22s.
- Five fresh constrained acceptance repetitions: 22/22 passed each time.
- Android test setup now includes the logged-in player state required by the unchanged production recovery guard. All 19 NativeRealtime tests and their assertions remain. This fixture correction has source validation only; Java compilation/tests must rerun in GitHub Actions.
- All other client and battle code is byte-identical to v3. Tiny synthetic artwork placeholders in the local workspace validate file/routing behavior only, not visual appearance.

The workflow runs all existing diagnostics and the full isolated DB suite, explicitly using two engine workers to preserve the regression condition. Native compilation, APK generation and device visual/two-account checks remain pending. The patch performs no deployment, production migration or point reset.
