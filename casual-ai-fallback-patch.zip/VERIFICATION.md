# Verification record

Validated in an isolated local artifact workspace using the pinned v2.2 source, official pinned npm dependencies, synthetic accounts and freshly created `/tmp/galmaegiman-tests-*/test.db` SQLite databases. No production `.env`, database, account or service was used.

- TypeScript `tsc --noEmit` and `npm run build`: passed.
- Three final focused repetitions: 83 tests passed each time.
- Official pinned `vitest.config.ts` restored and Git-blob verified; final unfiltered invocation: `node scripts/test-db.mjs` (the `npm run test:db` script).
- Complete server suite: 386 tests in 27 source files passed (324 existing + 62 additional AI, population, acceptance and web-client regressions).
- Acceptance tests cover both-ready gating, exact deadline, declines, durable requeue, late cancellation, subsequent-match protection, protocol upgrades and no pre-accept rating/item effects.
- New tests cover the 30-second boundary, human priority, queue cancellation races, simultaneous arrival, lease expiry, exactly one room, ranked never falling back, preparation timeout, durable/private precommit, restart/reroll, unauthenticated bot identity, no MMR/LP/statistics settlement, battle victory, timeout forfeiture, item idempotency and failed-resolution refund.
- Bot helper tests cover deterministic strategy/no RNG mutation, forced replacement plus augment, validated free-switch follow-up, item rejection and no mutation on bad input.
- Actual static artwork was not available in the local test fixture. Tiny synthetic image placeholders were used only for existing routing/file-presence tests; no artwork or appearance claim is made.
- Client source transformation is validated against exact v2.2 client payloads. Android compilation/unit tests and native/web visual checks are deferred to the delivered GitHub Actions workflow and device verification.
- Installer validated on a disposable exact-before fixture: all 14 file hashes, dry-run, apply, and idempotent reapply passed. Both CI jobs retain the original v2.2 extraction and add the separate patch afterward.
- Existing diagnostic tests are retained. No tests are removed or skipped to pass the new feature.

The accompanying full CI workflow must be run after upload. The ZIP does not deploy code, modify the live DB, or reset points. Do not interpret local test success as deployment or device verification.
