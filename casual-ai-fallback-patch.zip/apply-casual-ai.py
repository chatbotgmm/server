#!/usr/bin/env python3
"""Manual source-only patch for the generated realtime v2.2 release. Default: dry-run."""
from pathlib import Path
import argparse, hashlib, json, os, stat, tempfile

HERE=Path(__file__).resolve().parent

def sha(data): return hashlib.sha256(data).hexdigest()

def prepare(root:Path,payload:Path):
    root=root.resolve(strict=True)
    manifest=json.loads((payload/'manifest.json').read_text())
    outputs={}; states=[]
    for entry in manifest['files']:
        rel=Path(entry['target'])
        if rel.is_absolute() or '..' in rel.parts: raise ValueError('Unsafe target')
        target=root/rel
        if target.is_symlink() or not target.resolve().is_relative_to(root): raise ValueError('Unsafe target path: '+str(rel))
        source=payload/entry['payload']
        if not source.resolve().is_relative_to(payload.resolve()): raise ValueError('Unsafe payload path')
        data=source.read_bytes()
        if sha(data)!=entry['after']: raise ValueError('Payload hash mismatch: '+str(rel))
        current=target.read_bytes() if target.exists() else None
        digest=sha(current) if current is not None else None
        if digest==entry['after']: states.append('after')
        elif digest==entry['before']: states.append('before')
        else: raise ValueError('Source differs from generated v2.2: '+str(rel))
        outputs[target]=data
    if states and all(x=='after' for x in states): return {}
    if any(x=='after' for x in states): raise ValueError('Partial application detected; inspect backups before retrying')
    for target in outputs:
        backup=Path(str(target)+'.casual-ai-v3.bak')
        if os.path.lexists(backup): raise ValueError('Backup already exists: '+str(backup))
    return outputs

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--root',type=Path,default=HERE,help='Repository/worktree root, containing galmaegiman-confirmed')
    ap.add_argument('--apply',action='store_true')
    args=ap.parse_args(); outputs=prepare(args.root,HERE/'casual-ai-payload')
    if not outputs:
        print('Casual AI patch is already applied exactly. No changes.'); return
    for p in outputs: print('SOURCE:',p)
    if not args.apply:
        print(f'Dry-run passed: {len(outputs)} source files. No files, DB, service or scores changed.');return
    # Complete all source/backup validation before any writes. Preserve every replaced source.
    for p in outputs:
        if p.exists():
            with Path(str(p)+'.casual-ai-v3.bak').open('xb') as f: f.write(p.read_bytes());f.flush();os.fsync(f.fileno())
    staged=[]
    try:
        for p,data in outputs.items():
            p.parent.mkdir(parents=True,exist_ok=True)
            fd,name=tempfile.mkstemp(prefix='.'+p.name+'.casual-ai-',dir=p.parent)
            with os.fdopen(fd,'wb') as f: f.write(data);f.flush();os.fsync(f.fileno())
            os.chmod(name,stat.S_IMODE(p.stat().st_mode) if p.exists() else 0o644)
            staged.append((Path(name),p))
        for tmp,p in staged: os.replace(tmp,p)
    finally:
        for tmp,_ in staged:
            if tmp.exists(): tmp.unlink()
    print('Casual AI SOURCE patch applied. Build, tests, deployment and DB operations were NOT run.')

if __name__=='__main__': main()
