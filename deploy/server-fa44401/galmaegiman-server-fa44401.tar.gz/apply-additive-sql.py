# 새 표·열·색인만 추가한다(기존 데이터 삭제·변경 없음). 이미 있는 항목은 건너뛴다. 전부 한 트랜잭션.
# 사용: python3 apply-additive-sql.py <DB 파일> <migration.sql> [<migration.sql> ...]
import re,sqlite3,sys
db=sqlite3.connect(sys.argv[1]);db.isolation_level=None
def stmts(path):
    text='\n'.join(l for l in open(path,encoding='utf-8').read().splitlines() if not l.strip().startswith('--'))
    return [s.strip() for s in text.split(';') if s.strip()]
def exists(s):
    m=re.match(r'CREATE TABLE "([^"]+)"',s)
    if m: return db.execute("select count(*) from sqlite_master where type='table' and name=?",(m[1],)).fetchone()[0]>0
    m=re.match(r'CREATE (?:UNIQUE )?INDEX "([^"]+)"',s)
    if m: return db.execute("select count(*) from sqlite_master where type='index' and name=?",(m[1],)).fetchone()[0]>0
    m=re.match(r'ALTER TABLE "([^"]+)" ADD COLUMN "([^"]+)"',s)
    if m: return any(r[1]==m[2] for r in db.execute('pragma table_info("%s")'%m[1]))
    raise SystemExit('추가 전용이 아닌 문장이라 중단: '+s[:80])
plan=[(p,s) for p in sys.argv[2:] for s in stmts(p)]
for p,s in plan: exists(s)   # 먼저 전부 추가 전용인지 확인
db.execute('BEGIN IMMEDIATE')
try:
    done=skip=0
    for p,s in plan:
        if exists(s): skip+=1
        else: db.execute(s); done+=1
    db.execute('COMMIT')
except Exception as e:
    db.execute('ROLLBACK'); print('SQL 실패, 되돌림:',e); sys.exit(1)
print('SQL 적용 %d개, 이미 있어 건너뜀 %d개'%(done,skip))
print('DB 무결성',db.execute('pragma integrity_check').fetchone()[0])
