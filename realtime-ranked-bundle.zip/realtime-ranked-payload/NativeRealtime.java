package org.dpdns.gmm;

import android.content.SharedPreferences;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.LinearLayout;
import java.util.ArrayList;
import java.net.URLEncoder;
import java.util.UUID;
import org.json.JSONArray;
import org.json.JSONObject;

/** Draft: authenticated server-owned PvP. Never resolves a turn on the device. */
final class NativeRealtime {
  final MainActivity h;
  final SharedPreferences prefs;
  boolean resumed, closed, reading, writing, cancelling, preparing, inspecting, playing;
  int generation;
  String owner = "", mode = "rank", attempt = "", token = "", room = "";
  String cancelRequest = "", dismissed = "";
  JSONObject latest, pendingPlayback;
  long serverAtReceive, receivedElapsed;
  TextView queueText, clock;
  Button cancelButton, retryButton;
  final Runnable poll = this::refresh;
  final Runnable tick = new Runnable() {
    public void run() {
      if (!resumed || closed) return;
      if (clock != null && latest != null && clock.isAttachedToWindow()) {
        long deadline = latest.optLong("deadline", 0);
        long now = serverAtReceive + SystemClock.elapsedRealtime() - receivedElapsed;
        String remaining = deadline > 0 ? Math.max(0, (deadline - now + 999) / 1000) + "초 · " : "";
        String state = latest.optJSONObject("result") != null ? "결과 확인 중"
            : "prepare".equals(latest.optString("phase")) ? "팀 편성 · 준비 완료를 눌러 주세요"
            : writing ? "선택 전송 중" : latest.optBoolean("mySubmitted") ? "상대 선택 대기"
            : latest.optBoolean("canSubmit") ? "행동 선택" : "상대 선택 대기";
        clock.setText(remaining + state);
      }
      h.api.ui.postDelayed(this, 250);
    }
  };

  NativeRealtime(MainActivity host) {
    h = host;
    prefs = h.getSharedPreferences("native_realtime", 0);
  }
  static String id() { return UUID.randomUUID().toString(); }
  static boolean isBattle(JSONObject b) { return b != null && b.optBoolean("realtime"); }
  String account() {
    try {
      byte[] d = java.security.MessageDigest.getInstance("SHA-256")
          .digest(h.api.token().getBytes(java.nio.charset.StandardCharsets.UTF_8));
      StringBuilder out = new StringBuilder();
      for (byte v : d) out.append(String.format(java.util.Locale.ROOT, "%02x", v & 255));
      return out.toString();
    } catch (Exception e) { throw new IllegalStateException(e); }
  }
  boolean valid(int g, String a) {
    return !closed && !h.isFinishing() && !h.isDestroyed() && g == generation
        && !h.api.token().isEmpty() && a.equals(account());
  }
  void save() {
    prefs.edit().putString("owner", owner).putString("attempt", attempt)
        .putString("token", token).putString("room", room)
        .putString("mode", mode).putString("cancelRequest", cancelRequest)
        .putBoolean("cancelling", cancelling).putString("dismissed", dismissed).apply();
  }
  void loadSaved() {
    String current = account();
    if (!current.equals(owner)) {
      generation++; reading = writing = preparing = inspecting = playing = false;
      latest = pendingPlayback = null;
      owner = current;
      boolean same = current.equals(prefs.getString("owner", ""));
      attempt = same ? prefs.getString("attempt", "") : "";
      token = same ? prefs.getString("token", "") : "";
      room = same ? prefs.getString("room", "") : "";
      mode = same ? prefs.getString("mode", "rank") : "rank";
      cancelRequest = same ? prefs.getString("cancelRequest", "") : "";
      cancelling = same && prefs.getBoolean("cancelling", false);
      dismissed = same ? prefs.getString("dismissed", "") : "";
      if (!same) save();
    }
  }
  void resume() {
    resumed = true;
    h.api.ui.removeCallbacks(tick); h.api.ui.post(tick);
    recover();
  }
  void recover() {
    if (!resumed || closed || h.api.token().isEmpty() || !h.state.has("me")) return;
    loadSaved();
    if (reading || writing || preparing) return;
    if (attempt.isEmpty() && room.isEmpty() && !cancelling) return;
    if (cancelling && !attempt.isEmpty() && !token.isEmpty()) { sendCancel(); return; }
    refresh();
  }
  void pause() {
    resumed = false;
    h.api.ui.removeCallbacks(poll); h.api.ui.removeCallbacks(tick);
    // The server lease/deadline continues. Backgrounding never surrenders.
  }
  void close() { pause(); closed = true; generation++; }
  void schedule() {
    h.api.ui.removeCallbacks(poll);
    if (resumed && !closed && (!attempt.isEmpty() || !room.isEmpty())) h.api.ui.postDelayed(poll, 1000);
  }
  void begin(String selectedMode) {
    if (h.api.token().isEmpty()) { h.login(); return; }
    loadSaved();
    if (preparing || inspecting) return;
    if (!room.isEmpty() || !attempt.isEmpty() || cancelling) { showQueue("진행 상태 확인 중…"); recover(); return; }
    generation++; mode = selectedMode; preparing = true; writing = reading = false;
    latest = null; dismissed = ""; save(); showQueue("진행 중인 매칭 확인 중…");
    inspectCurrent(true);
  }
  void inspectCurrent(boolean startWhenIdle) {
    if (inspecting) return;
    inspecting = preparing = true;
    final int g = generation; final String a = owner;
    h.api.call("pvp/queue/current", null, (r, e) -> {
      if (!valid(g, a)) return;
      inspecting = preparing = false;
      if (e != null) { queueError(e); return; }
      String status = r.optString("status");
      if (status.equals("idle") || status.equals("cancelled") || status.equals("expired")) {
        if (cancelling || !startWhenIdle) { clearQueue(); h.load("modes"); }
        else prepareAttempt();
      } else acceptQueue(r);
    });
  }
  void prepareAttempt() {
    preparing = true; showQueue("대전 연결 준비 중…");
    final int g = generation; final String a = owner;
    h.api.call("pvp/queue/attempt", MainActivity.obj("mode", mode), (r, e) -> {
      if (!valid(g, a)) return;
      preparing = false;
      if (e != null) { queueError(e); return; }
      attempt = r.optString("attemptId"); token = r.optString("token");
      if (attempt.isEmpty() || token.isEmpty()) { queueError("매칭 준비 응답을 확인하지 못했어요."); return; }
      save(); join();
    });
  }
  void join() {
    if (cancelling) { sendCancel(); return; }
    writing = true; final int g = generation; final String a = owner;
    showQueue("상대를 찾고 있어요…");
    h.api.call("pvp/queue/join", MainActivity.obj("attemptId", attempt, "token", token), (r, e) -> {
      if (!valid(g, a)) return;
      writing = false;
      if (cancelling) { sendCancel(); return; }
      if (e != null) { queueError(e); schedule(); return; }
      acceptQueue(r);
    });
  }
  boolean back() {
    if ("realtimePrepare".equals(h.screen)) {
      new GameDialog(h).setTitle("대전에서 나갈까요?")
          .setMessage("매칭 후 나가면 패배로 기록돼요.")
          .setPositiveButton("나가기", (d, w) -> surrender())
          .setNegativeButton("계속 편성", null).show();
      return true;
    }
    if (!"realtimeQueue".equals(h.screen)) return false;
    cancel(); return true;
  }
  void cancel() {
    if (!room.isEmpty()) { refresh(); return; }
    if (inspecting) {
      cancelling = true; if (cancelRequest.isEmpty()) cancelRequest = id();
      save(); showQueue("매칭 취소 확인 중…"); return;
    }
    if (attempt.isEmpty() && token.isEmpty()) {
      // Attempt issuance is inert: invalidating this response cannot leave a queue entry.
      generation++; preparing = false; writing = reading = false;
      clearQueue(); h.load("modes"); return;
    }
    cancelling = true;
    if (cancelRequest.isEmpty()) cancelRequest = id();
    generation++; writing = reading = false;
    h.api.ui.removeCallbacks(poll); save();
    showQueue("매칭 취소 확인 중…"); sendCancel();
  }
  void sendCancel() {
    if (writing || closed) return;
    if (attempt.isEmpty() || token.isEmpty()) { inspectCurrent(false); return; }
    writing = true; final int g = generation; final String a = owner;
    h.api.call("pvp/queue/cancel", MainActivity.obj("attemptId", attempt, "token", token,
        "requestId", cancelRequest), (r, e) -> {
      if (!valid(g, a)) return;
      writing = false;
      if (e != null) { queueError("취소 여부를 확인하지 못했어요. " + e); return; }
      acceptQueue(r);
    });
  }
  void clearQueue() {
    attempt = token = cancelRequest = ""; cancelling = false; preparing = false; save();
  }
  void showQueue(String message) {
    if (!"realtimeQueue".equals(h.screen)) {
      h.busy = false;
      h.base(mode.equals("rank") ? "실시간 랭크 매칭" : "실시간 일반 매칭", "realtimeQueue");
      queueText = h.text(message, 20); h.body.addView(queueText);
      cancelButton = h.button("매칭 취소", this::cancel); h.body.addView(cancelButton);
      retryButton = h.button("상태 다시 확인", () -> {
        if (cancelling) sendCancel(); else if (attempt.isEmpty()) begin(mode); else refresh();
      }); h.body.addView(retryButton);
    }
    queueText.setText(message);
    cancelButton.setEnabled(!cancelling);
    retryButton.setVisibility(View.GONE);
  }
  void queueError(String error) {
    showQueue(error);
    retryButton.setText(cancelling ? "취소 다시 시도" : "상태 다시 확인");
    retryButton.setVisibility(View.VISIBLE);
    if (h.api.token().isEmpty()) h.login();
  }
  void acceptQueue(JSONObject q) {
    String status = q.optString("status");
    mode = q.optString("mode", mode);
    if (q.has("attemptId")) attempt = q.optString("attemptId");
    if (q.has("token")) token = q.optString("token");
    if (status.equals("matched")) {
      boolean lostCancelRace = cancelling;
      room = q.optString("roomId"); clearQueue(); save();
      if (room.isEmpty()) { queueError("대전 번호가 없어요. 상태를 다시 확인해 주세요."); return; }
      if (room.equals(dismissed)) { room = ""; save(); return; }
      if (lostCancelRace) h.message("매칭이 먼저 완료됐어요. 대전으로 돌아가요.");
      refresh(); return;
    }
    if (status.equals("idle") && !attempt.isEmpty() && !token.isEmpty()) {
      // A delayed join may still commit after this read. Tombstone the known attempt first.
      cancelling = true; if (cancelRequest.isEmpty()) cancelRequest = id();
      save(); showQueue("매칭 취소 확인 중…"); sendCancel(); return;
    }
    if (status.equals("cancelled") || status.equals("expired") || status.equals("idle")) {
      boolean wasActive = "realtimeQueue".equals(h.screen);
      clearQueue(); if (wasActive) h.load("modes"); return;
    }
    save();
    if (cancelling) { sendCancel(); return; }
    if (status.equals("preparing")) { join(); return; }
    if (!status.equals("waiting")) { queueError("매칭 상태를 확인하지 못했어요."); return; }
    showQueue("상대를 찾고 있어요…\n기다리는 동안 취소할 수 있어요."); schedule();
  }
  void refresh() {
    if (closed || !resumed || reading || writing || preparing || h.api.token().isEmpty()) return;
    if (cancelling && !writing) { sendCancel(); return; }
    reading = true; final int g = generation; final String a = owner;
    final String requestedRoom = room;
    String path = requestedRoom.isEmpty() ? "pvp/queue/current" : "pvp/room/current?roomId=" + encode(requestedRoom);
    h.api.call(path, null, (r, e) -> {
      if (!valid(g, a)) return;
      reading = false;
      if (e != null) {
        if (h.api.token().isEmpty()) { h.login(); return; }
        if (room.isEmpty()) queueError(e);
        else if (clock != null) clock.setText("연결 확인 중… 서버 제한 시간은 계속돼요.");
        schedule(); return;
      }
      if (requestedRoom.isEmpty()) acceptQueue(r);
      else if (requestedRoom.equals(room)) acceptRoom(r);
      schedule();
    });
  }
  static String encode(String s) {
    try { return URLEncoder.encode(s, "UTF-8"); } catch (Exception e) { throw new IllegalStateException(e); }
  }
  JSONObject decorate(JSONObject envelope) {
    JSONObject b = copy(envelope.optJSONObject("battle"));
    try {
      b.put("realtime", true); b.put("session", room); b.put("phaseId", envelope.optString("phaseId"));
      b.put("revision", envelope.optLong("revision")); b.put("mode", envelope.optString("mode", mode));
      // Transport busy is transient; submit() guards it without poisoning an equal-revision view.
      b.put("canSubmit", envelope.optBoolean("canSubmit"));
      b.put("mySubmitted", envelope.optBoolean("mySubmitted"));
      b.put("serverNow", envelope.optLong("serverNow"));
      b.put("chooseDeadline", envelope.optLong("deadline", 0));
    } catch (Exception e) { throw new IllegalStateException(e); }
    return b;
  }
  static JSONObject copy(JSONObject o) {
    try { return o == null ? new JSONObject() : new JSONObject(o.toString()); }
    catch (Exception e) { throw new IllegalArgumentException(e); }
  }
  void acceptRoom(JSONObject r) {
    if (!room.equals(r.optString("roomId"))) return;
    if (latest != null && r.optLong("revision") < latest.optLong("revision")) return;
    mode = r.optString("mode", mode); save();
    boolean changed = latest == null || r.optLong("revision") != latest.optLong("revision")
        || r.optBoolean("canSubmit") != latest.optBoolean("canSubmit")
        || !r.optString("result").equals(latest.optString("result"));
    latest = copy(r); serverAtReceive = r.optLong("serverNow", System.currentTimeMillis());
    receivedElapsed = SystemClock.elapsedRealtime();
    if (r.optJSONObject("result") != null && r.optJSONObject("battle") == null) {
      if (changed || !"realtimePrepare".equals(h.screen)) {
        h.battle = null; h.busy = false; h.base("대전 결과", "realtimePrepare");
        h.body.addView(h.text("대전 결과를 확인하고 있어요.", 18)); attachClock();
      }
      terminal(r); return;
    }
    if ("prepare".equals(r.optString("phase"))) {
      if (changed || !"realtimePrepare".equals(h.screen)) showPreparation(r);
      return;
    }
    if (playing) { pendingPlayback = copy(r); return; }
    if (!changed && isBattle(h.battle) && "battle".equals(h.screen)) return;
    if (h.visibleDialog != null) { h.visibleDialog.dismiss(); h.visibleDialog = null; }
    JSONObject next = decorate(r);
    BattleView view = currentView();
    final int g = generation; final String a = owner;
    Runnable done = () -> {
      if (!valid(g, a)) return;
      playing = false; h.busy = false; h.battle = next; h.battleScreen(); attachClock();
      if (pendingPlayback != null) {
        JSONObject p = pendingPlayback; pendingPlayback = null;
        // Force application: latest may already contain this coalesced snapshot.
        latest = null; acceptRoom(p); return;
      }
      terminal(r);
    };
    if (view != null && isBattle(h.battle) && room.equals(h.battle.optString("session"))
        && next.optLong("displayEventSeq") > h.battle.optLong("displayEventSeq")) {
      playing = true; view.playTo(next, done);
    } else done.run();
  }
  BattleView currentView() {
    for (int i = 0; i < h.root.getChildCount(); i++)
      if (h.root.getChildAt(i) instanceof BattleView) return (BattleView) h.root.getChildAt(i);
    return null;
  }
  void showPreparation(JSONObject r) {
    JSONObject preparation = r.optJSONObject("preparation");
    if (preparation == null) { h.message("팀 편성 정보를 확인하지 못했어요."); return; }
    if (h.visibleDialog != null) { h.visibleDialog.dismiss(); h.visibleDialog = null; }
    h.battle = null; h.busy = false;
    h.base(mode.equals("rank") ? "랭크 대전 · 팀 편성" : "일반 대전 · 팀 편성", "realtimePrepare");
    h.body.addView(h.text("30초 안에 출전 순서를 골라 주세요. 둘 다 준비되면 바로 시작해요.", 16));
    h.body.addView(h.text("시간이 끝나면 마지막으로 저장된 편성으로 시작해요.", 14));
    JSONArray selected = h.list(preparation, "selectedIds"), available = h.list(preparation, "available");
    boolean ready = preparation.optBoolean("ready");
    LinearLayout row = new LinearLayout(h);
    for (int i = 0; i < selected.length(); i++) {
      final int slot = i;
      String id = selected.optString(i), name = id;
      for (int j = 0; j < available.length(); j++) {
        JSONObject candidate = available.optJSONObject(j);
        if (id.equals(candidate.optString("id"))) name = candidate.optString("name", id);
      }
      Button button = h.button((i == 0 ? "선봉" : (i + 1) + "번") + "\n" + name,
          () -> choosePreparationSlot(r, slot));
      button.setEnabled(!ready);
      row.addView(button, new LinearLayout.LayoutParams(0, h.dp(80), 1));
    }
    h.body.addView(row);
    h.body.addView(h.text(preparation.optBoolean("opponentReady") ? "상대 준비 완료" : "상대가 팀을 고르고 있어요.", 16));
    Button confirm = h.button(ready ? "준비 완료 · 상대를 기다려요" : "이 편성으로 준비 완료",
        () -> prepareCommand(r, selected, true));
    confirm.setEnabled(!ready && selected.length() == 3);
    h.body.addView(confirm);
    h.body.addView(h.button("대전 나가기", () -> back()));
    attachClock();
  }
  boolean currentPreparation(JSONObject shown) {
    return latest != null && !writing && room.equals(shown.optString("roomId"))
        && "prepare".equals(latest.optString("phase"))
        && shown.optString("phaseId").equals(latest.optString("phaseId"))
        && latest.optJSONObject("preparation") != null
        && !latest.optJSONObject("preparation").optBoolean("ready");
  }
  void choosePreparationSlot(JSONObject shown, int slot) {
    if (!currentPreparation(shown)) { refresh(); return; }
    JSONObject p = shown.optJSONObject("preparation");
    JSONArray selected = h.list(p, "selectedIds"), candidates = h.list(p, "available");
    ArrayList<String> ids = new ArrayList<>(), names = new ArrayList<>();
    for (int i = 0; i < candidates.length(); i++) {
      JSONObject candidate = candidates.optJSONObject(i); String id = candidate.optString("id");
      ids.add(id); names.add(candidate.optString("name") + " · " + candidate.optString("rarity"));
    }
    new GameDialog(h).setTitle("출전 갈매미 선택 · 다른 자리에 있으면 순서 교환")
        .setItems(names.toArray(new String[0]), (d, which) -> {
          JSONArray team = new JSONArray();
          String chosen = ids.get(which), old = selected.optString(slot);
          for (int i = 0; i < selected.length(); i++)
            team.put(i == slot ? chosen : selected.optString(i).equals(chosen) ? old : selected.optString(i));
          prepareCommand(shown, team, false);
        }).setNegativeButton("돌아가기", null).show();
  }
  void prepareCommand(JSONObject shown, JSONArray team, boolean ready) {
    if (!currentPreparation(shown)) { refresh(); return; }
    sendCommand(shown.optString("phaseId"), MainActivity.obj("prepare", MainActivity.obj("team", team, "ready", ready)));
  }
  void attachClock() {
    clock = h.text("", 13); clock.setGravity(Gravity.CENTER);
    clock.setTextColor(JournalTheme.INK); clock.setBackgroundColor(0xeefbf0d7);
    clock.setPadding(h.dp(8), h.dp(2), h.dp(8), h.dp(2));
    FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.RIGHT);
    lp.topMargin = h.dp(4); lp.rightMargin = h.dp(8);
    h.root.addView(clock, lp);
  }
  void submit(JSONObject shown, JSONObject event) {
    if (!isBattle(shown) || latest == null || writing || playing) return;
    if (!room.equals(shown.optString("session")) || !shown.optString("phaseId").equals(latest.optString("phaseId"))) {
      h.message("턴이 바뀌었어요. 현재 화면에서 다시 선택해 주세요."); refresh(); return;
    }
    if (event.optBoolean("leave")) { surrender(); return; }
    if (!latest.optBoolean("canSubmit")) { h.message("선택을 이미 보냈어요. 상대를 기다려 주세요."); return; }
    JSONObject action = event.optJSONObject("action");
    if (action != null && "switch".equals(action.optString("kind")) && !action.has("then") && freeSwitch(shown)) {
      followup(shown, action); return;
    }
    sendCommand(shown.optString("phaseId"), event);
  }
  boolean freeSwitch(JSONObject b) {
    JSONObject team = h.list(b, "teams").optJSONObject(0);
    if (team == null) return false;
    JSONArray augs = h.list(team, "augments");
    for (int i = 0; i < augs.length(); i++) {
      JSONObject aug = augs.optJSONObject(i);
      if (aug != null && "freeswitch".equals(aug.optString("id"))) return true;
    }
    return false;
  }
  void followup(JSONObject shown, JSONObject action) {
    JSONObject own = h.list(shown, "teams").optJSONObject(0);
    JSONObject choices = own == null ? null : own.optJSONObject("switchFollowups");
    JSONArray skills = choices == null ? null : choices.optJSONArray(String.valueOf(action.optInt("to")));
    if (skills == null || skills.length() == 0) { h.message("교체 후 기술을 불러오지 못했어요."); refresh(); return; }
    String[] labels = new String[skills.length()];
    for (int i = 0; i < labels.length; i++) labels[i] = skills.optJSONObject(i).optString("name");
    new GameDialog(h).setTitle("교체 후 사용할 기술")
        .setItems(labels, (dialog, which) -> {
          JSONObject next = copy(action);
          try { next.put("then", skills.optJSONObject(which).optString("id")); } catch (Exception e) { return; }
          submit(shown, MainActivity.obj("action", next));
        }).setNegativeButton("돌아가기", null).show();
  }
  void sendCommand(String phaseId, JSONObject event) {
    JSONObject command = new JSONObject();
    try {
      for (String key : new String[] {"action", "choose", "reroll", "prepare"}) if (event.has(key)) command.put(key, event.get(key));
    } catch (Exception e) { h.message("선택 내용을 확인해 주세요."); return; }
    writing = true; final int g = generation; final String a = owner;
    h.api.call("pvp/room/command", MainActivity.obj("roomId", room, "phaseId", phaseId,
        "requestId", id(), "command", command), (r, e) -> {
      if (!valid(g, a)) return;
      writing = false;
      if (e != null) { h.message(e + " 현재 대전 상태를 확인할게요."); refresh(); return; }
      acceptRoom(r); schedule();
    });
  }
  void surrender() {
    if (writing || room.isEmpty()) return;
    writing = true; final int g = generation; final String a = owner;
    h.api.call("pvp/room/surrender", MainActivity.obj("roomId", room, "requestId", id()), (r, e) -> {
      if (!valid(g, a)) return;
      writing = false;
      if (e != null) { h.message(e); refresh(); return; }
      acceptRoom(r); schedule();
    });
  }
  String shownResult = "";
  void terminal(JSONObject r) {
    JSONObject result = r.optJSONObject("result");
    if (result == null || "pending".equals(result.optString("settlement")) || room.equals(shownResult)) return;
    shownResult = room;
    boolean draw = result.isNull("winner");
    String label = "SERVER_ABORT".equals(result.optString("reason")) ? "대전 종료"
        : draw ? "무승부" : result.optInt("winner", 1) == 0 ? "승리" : "패배";
    JSONObject rank = result.optJSONObject("rank");
    JSONObject after = rank == null ? null : rank.optJSONObject("after");
    String detail = !mode.equals("rank") || after == null ? "대전 결과가 저장됐어요."
        : rank.optString("tier") + " · " + after.optInt("lp") + " LP"
            + (after.optBoolean("promotionActive") ? " · 승급전 " + after.optInt("promotionWins")
                + "승 " + after.optInt("promotionLosses") + "패" : "")
            + ("PROMOTED".equals(rank.optString("promotionChange")) ? "\n승급했어요!"
                : "FAILED".equals(rank.optString("promotionChange")) ? "\n승급전에 실패했어요." : "");
    new GameDialog(h).setTitle(label).setMessage(detail).setCancelable(false)
        .setPositiveButton("모드 선택", (d, w) -> {
          dismissed = room; room = ""; latest = null; shownResult = ""; generation++;
          reading = writing = playing = false; pendingPlayback = null; h.battle = null;
          h.api.ui.removeCallbacks(poll); save(); h.load("modes");
        }).show();
  }
}
