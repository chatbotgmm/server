import {RealtimeRankedClient} from './realtime-ranked-client.js';

const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
// Separate presentation adapter: no createBattle, act, pickAi, aiChoose or replay settlement.
export function createRealtimeScreen({api,host,confirmLeave,onExit,imageBase=''}) {
  let visible=false,phase=null,augment=null,switchTo=null,followup=null;
  const root=document.createElement('section');root.className='rt-ranked';root.hidden=true;host.append(root);
  const style=document.createElement('style');style.textContent=`
  .rt-ranked[hidden]{display:none!important}.rt-ranked{position:fixed;inset:0;z-index:250;background:#2b231df5;color:#3d2918;display:grid;place-items:center;padding:1.5vh 2vw;box-sizing:border-box}
  .rt-paper{width:min(1100px,96vw);height:96dvh;box-sizing:border-box;background:linear-gradient(110deg,#eddbb3,#fff1ce 50%,#e5c99c);border:3px solid #79572f;border-radius:18px;box-shadow:0 8px 35px #0008;display:flex;flex-direction:column;gap:8px;padding:clamp(8px,2vh,20px);overflow:hidden}
  .rt-paper h2,.rt-paper p{margin:0}.rt-head,.rt-row,.rt-team{display:flex;align-items:center;justify-content:space-between;gap:8px}.rt-head{flex-wrap:wrap}.rt-clock{font-weight:800;font-variant-numeric:tabular-nums}.rt-arena{display:grid;grid-template-columns:1fr 1fr;gap:16px;min-height:0;flex:1}.rt-side{display:flex;align-items:center;gap:10px;min-height:0}.rt-side img{width:clamp(50px,12vw,160px);max-height:22vh;object-fit:contain}.rt-side meter{width:100%}.rt-side small{display:block}.rt-controls{flex:0 1 auto;min-height:0;display:grid;gap:6px}.rt-options{display:flex;gap:8px;min-height:0}.rt-options>button,.rt-options>article{flex:1;min-width:0}.rt-ranked button{color:#3d2918;background:#fff5d8;border:2px solid #a3824f;border-radius:10px;padding:8px;cursor:pointer}.rt-ranked button:disabled{opacity:.5;cursor:default}.rt-ranked button[aria-pressed=true]{border-color:#593800;background:#f4cb72}.rt-aug{padding:8px;border:1px solid #b59460;border-radius:10px;display:flex;flex-direction:column;gap:6px}.rt-aug>button:first-child{flex:1}.rt-aug b,.rt-aug small{display:block}.rt-aug small{font-size:clamp(10px,1.6vh,15px)}.rt-log{font-size:12px;white-space:nowrap;text-overflow:ellipsis;overflow:hidden}.rt-error{color:#8a241b}.rt-foot{font-size:12px}.rt-actions{display:flex;flex-wrap:wrap;gap:6px}.rt-actions button{flex:1}.rt-queue{justify-content:center;text-align:center;height:auto;min-height:40vh}.rt-sr{position:absolute;left:-9999px}
  @media(max-height:550px){.rt-paper{gap:4px;padding:8px}.rt-paper h2{font-size:17px}.rt-ranked button{padding:5px}.rt-side img{max-height:16vh}.rt-aug{padding:4px}.rt-foot{font-size:10px}.rt-log{display:none}}
  `;document.head.append(style);
  const client=new RealtimeRankedClient({api,onChange:draw});
  const show=()=>{visible=true;root.hidden=false;draw(client.state);};
  const close=()=>{if(client.dismiss()){visible=false;root.hidden=true;onExit();}};
  function button(label,cmd,disabled=false,pressed=false){return `<button data-cmd="${esc(cmd)}" ${disabled?'disabled':''} aria-pressed="${pressed}">${label}</button>`;}
  function draw(s) {
    if(!visible)return;
    const r=s.room,b=r?.battle,t=b?.teams?.[0],foe=b?.teams?.[1];
    if(!r){
      const terminal=['idle','cancelled','expired'].includes(s.status);
      const labels={preparing:'매칭 준비 중…',joining:'대기열에 들어가는 중…',waiting:'다른 유저를 찾고 있어요…',recovering:'진행 중인 대전 확인 중…',cancelling:'서버에 취소 확인 중…',cancelled:'매칭을 취소했어요.',expired:'매칭 시간이 만료됐어요.',idle:'진행 중인 매칭이 없어요.',matched:'상대가 정해졌어요. 대전 불러오는 중…'};
      root.innerHTML=`<div class="rt-paper rt-queue" role="dialog" aria-modal="true" aria-label="실시간 매칭"><h2>${esc(labels[s.status]||s.status)}</h2><p>실제 유저끼리 대전해요. AI로 자동 전환하지 않아요.</p><p class="rt-error" role="status">${esc(s.error)}</p>${terminal?button('돌아가기','close'):s.status==='matched'?'':button(s.status==='cancelling'?'취소 확인 중…':'취소','cancel',s.status==='cancelling')}<p class="rt-foot">취소보다 먼저 상대가 정해졌다면 대전으로 연결돼요.</p></div>`;
      if(s.error)root.querySelector('.rt-paper').insertAdjacentHTML('beforeend',button('상태 다시 확인 / 취소 재시도','retryStatus'));
      bind();return;
    }
    if(phase!==r.phaseId){phase=r.phaseId;augment=null;switchTo=null;followup=null;}
    if(augment && !t.offers.some(a=>a.id===augment))augment=null;
    const blocked=!r.canSubmit||r.mySubmitted||s.pending||!!r.result;
    const fighter=team=>{const f=team.fighters[team.active];return `<div class="rt-side"><img src="${esc(imageBase+f.image)}" alt=""><div><b>${esc(f.name)}</b><small>${esc(f.attr)} · ${f.hp}/${f.maxHp}</small><meter min="0" max="${f.maxHp}" value="${Math.max(0,f.hp)}"></meter><small>${(f.effects||[]).map(e=>esc(`${e.label} ${e.valueText}`)).join(' · ')}</small></div></div>`;};
    let controls='';
    if(r.result){
      const title=r.result.winner===null?'무승부':r.result.winner===0?'승리!':'패배';
      const delta=r.result.rank?.lpDelta;
      controls=`<h2>${title}</h2><p>${esc(r.result.reason)} · ${r.result.settlement==='pending'?'점수 확정 중…':r.mode==='rank'?`점수 확정 완료${typeof delta==='number'?` · LP ${delta>=0?'+':''}${delta}`:''}`:'일반전은 점수가 없어요.'}</p>${button('모드 고르기로','close')}`;
    } else if(b.phase==='choose') {
      controls=`<div class="rt-options">${t.offers.map((a,i)=>`<article class="rt-aug">${button(`<b>${esc(a.name)}</b><small>${esc(a.desc)}</small>`,`augment:${i}`,blocked,augment===a.id)}${button('다시 뽑기',`reroll:${i}`,blocked||a.rerolled)}</article>`).join('')}</div>`;
      if(t.needSwitch) controls+=`<div class="rt-actions">${t.fighters.map((f,i)=>button(esc(f.name),`chooseSwitch:${i}`,blocked||f.hp<=0,switchTo===i)).join('')}</div>`;
      const ready=(!t.offers.length||augment!==null)&&(!t.needSwitch||switchTo!==null);
      controls+=button('선택 확정','choose',blocked||!ready);
    } else if(b.phase==='action') {
      const f=t.fighters[t.active];
      controls=`<div class="rt-actions">${t.legal.filter(a=>a.kind==='skill').map((a,i)=>button(esc(f.skills.find(k=>k.id===a.skillId)?.name||a.skillId),`skill:${i}`,blocked)).join('')}</div><div class="rt-actions">${t.legal.filter(a=>a.kind==='switch').map((a,i)=>button(`교체: ${esc(t.fighters[a.to].name)}`,`switch:${i}`,blocked,switchTo===a.to)).join('')}</div>`;
      if(switchTo!==null){
        const free=t.augments.some(a=>a.id==='freeswitch');
        if(free){controls+=`<div class="rt-actions">${(t.switchFollowups?.[String(switchTo)]||[]).map((k,i)=>button(esc(k.name),`followup:${i}`,blocked,followup===k.id)).join('')}</div>`;}
        controls+=button(free?'교체 + 기술 확정':'교체 확정','switchConfirm',blocked||(free&&!followup));
      }
    }
    root.innerHTML=`<div class="rt-paper" role="dialog" aria-modal="true" aria-label="실시간 대전"><header class="rt-head"><h2>${r.mode==='rank'?'랭크게임':'일반게임'} · ${b.turn}턴</h2><span class="rt-clock"></span>${r.result?'':button('항복','surrender',s.pending)}</header><div class="rt-arena">${fighter(t)}${fighter(foe)}</div><p role="status">${r.mySubmitted?'선택 완료 · 상대를 기다려요.':r.opponentReady?'상대 선택 완료':'동시에 선택해요.'}</p><div class="rt-controls">${controls}</div><p class="rt-error" role="status">${esc(s.error)}</p>${s.error&&client.pendingCommand?button('같은 선택 다시 확인','retry'):''}${s.error&&client.pendingSurrender?button('항복 처리 다시 확인','surrenderRetry'):''}<p class="rt-log">${esc((b.log||[]).slice(-2).join(' / '))}</p><p class="rt-foot">30초가 지나면 서버가 기본 공격·교체·증강체를 자동 선택해요. 행동 3회 연속 미입력 시 패배해요.</p></div>`;
    bind();clock();
  }
  function bind(){const rendered=client.state.room,generation=client.generation;root.querySelectorAll('[data-cmd]').forEach(el=>el.onclick=async()=>{
    const [cmd,n]=el.dataset.cmd.split(':'),i=Number(n),r=client.state.room,t=r?.battle?.teams[0];
    if(generation!==client.generation)return;
    if(rendered && (r?.roomId!==rendered.roomId || r?.phaseId!==rendered.phaseId || r?.revision!==rendered.revision))return;
    if(cmd==='cancel')client.cancel();
    else if(cmd==='retryStatus'){client.startPolling();void client.tick();}
    else if(cmd==='close')close();
    else if(cmd==='retry')void client.retryCommand();
    else if(cmd==='surrenderRetry')void client.surrender();
    else if(cmd==='surrender'){if(await confirmLeave('항복하면 패배로 처리돼요. 항복할까요?')){const latest=client.state.room;if(generation===client.generation && latest?.roomId===rendered?.roomId && latest?.phaseId===rendered?.phaseId && !latest?.result)void client.surrender();}}
    else if(cmd==='augment'){augment=t.offers[i].id;draw(client.state);}
    else if(cmd==='chooseSwitch'){switchTo=i;draw(client.state);}
    else if(cmd==='reroll')void client.submit({reroll:i});
    else if(cmd==='choose')void client.submit({choose:{...(augment?{augment}:{}),...(switchTo!==null?{switchTo}:{})}});
    else if(cmd==='skill')void client.submit({action:t.legal.filter(a=>a.kind==='skill')[i]});
    else if(cmd==='switch'){switchTo=t.legal.filter(a=>a.kind==='switch')[i].to;followup=null;draw(client.state);}
    else if(cmd==='followup'){followup=t.switchFollowups[String(switchTo)][i].id;draw(client.state);}
    else if(cmd==='switchConfirm')void client.submit({action:{kind:'switch',to:switchTo,...(followup?{then:followup}:{})}});
  });}
  function clock(){const el=root.querySelector('.rt-clock'),sec=client.seconds();if(el)el.textContent=sec===null?'':`${sec}초`;}
  const clockTimer=setInterval(()=>{if(visible)clock();},250);
  document.addEventListener('visibilitychange',()=>{if(!document.hidden&&visible)void client.tick();});
  addEventListener('pagehide',()=>client.stop());
  addEventListener('pageshow',()=>{if(visible){client.startPolling();void client.tick();}});
  return {start(mode){show();void client.start(mode);},async restore(){
    const q=await api('pvp/queue/current');
    if(['preparing','waiting','matched'].includes(q.status)){show();await client.recover();}
  },destroy(){client.stop();clearInterval(clockTimer);root.remove();style.remove();}};
}
