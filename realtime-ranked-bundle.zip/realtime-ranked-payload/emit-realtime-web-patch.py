#!/usr/bin/env python3
"""Manual draft: prepare in memory or emit patch; never applies/builds/tests/deploys."""
import difflib
import hashlib
import json
from pathlib import Path
import subprocess
import sys

BASE='838f7ebd1d0617fd73f69bfcf6870a2cd463eaf2'
PATH='public/duel/duel.js'
EXPECTED='16dd189debe1695330a39d0f524af437f98ddc1e'
EDITS=json.loads("[[\"import { rulesFrom } from '../../src/battle/core.ts';\",\"import { createRealtimeScreen } from './realtime-ranked-screen.js';\\nimport { rulesFrom } from '../../src/battle/core.ts';\"],[\"async function pvpStart(mode) {\\n  let m;\\n  try { m = (await myApi('pvp/match', { mode })).result; }\\n  catch (e) {\\n    if (/전투 편성/.test(e.message)) { if (await ask(`${e.message}\\\\n지금 편성할까요?`, { ok: '전투 편성으로' })) openMy('battle'); return; }\\n    return tell(e.message);\\n  }\\n  // 상대 소개(VS)\\n  modal.className = ''; modal.hidden = false;\\n  const row = recs => recs.map(r => `<img src=\\\"${sprite(r.id, 'front', 0)}\\\" class=\\\"${tintOf(r.id)}\\\" alt=\\\"\\\" title=\\\"${esc(r.name)}\\\">`).join('');\\n  modal.innerHTML = `<div class=\\\"sheet pvs\\\"><small class=\\\"pvs-mode\\\">${mode === 'rank' ? '🏆 랭크게임' : '🤝 일반게임'} · 모두 Lv${m.mine[0].level}</small>\\n    <div class=\\\"pvs-row\\\"><div class=\\\"pvs-side me\\\"><b>${esc(ACC?.nickname || '내 수비대')}</b><div class=\\\"pvs-team\\\">${row(m.mine)}</div></div><em class=\\\"pvs-vs\\\">VS</em>\\n    <div class=\\\"pvs-side foe\\\"><b>${esc(m.foeName)}</b>${m.foeTier ? `<small>${esc(m.foeTier)}</small>` : m.bot ? '<small>상대가 없어 연습 팀과 붙어요</small>' : ''}<div class=\\\"pvs-team\\\">${row(m.foe)}</div></div></div>\\n    <button class=\\\"big wide\\\" id=\\\"pvsGo\\\">대전 시작</button>${mode === 'rank' ? '<p class=\\\"sub\\\">랭크는 중간에 나가면 패배로 처리돼요.</p>' : ''}</div>`;\\n  modal.querySelector('#pvsGo').onclick = () => {\\n    modal.hidden = true; sceneNow = 'harbor'; fightId = null;\\n    startBattle(m.mine, m.foe, won => {\\n      const sent = pvp; pvp = null;\\n      myApi('pvp/result', { match: sent.match, log: sent.log }).then(r => {\\n        const t = r.result, el = document.querySelector('#panel .sheet .sub');\\n        if (el) el.textContent = t.mode === 'rank' ? `랭크 ${t.change >= 0 ? '+' : ''}${t.change}점 → ${t.point}점 (${t.tier}) · ${t.wins}승 ${t.losses}패` : '일반게임은 점수가 없어요. 랭크게임에서 실력을 겨뤄 봐요!';\\n      }).catch(e => { const el = document.querySelector('#panel .sheet .sub'); if (el) el.textContent = `결과를 확인하지 못했어요: ${e.message}`; });\\n      return { text: mode === 'rank' ? '결과 확인 중…' : '결과 확인 중…', buttons: [['한 판 더', () => pvpStart(mode)], ['모드 고르기로', modeScreen]] };\\n    }, '', { retry: () => pvpStart(mode), back: modeScreen }, m.seed);\\n    pvp = { match: m.match, mode, log: [] };\\n  };\\n}\\n\",\"let realtimeScreen;\\nfunction getRealtimeScreen() {\\n  if (!realtimeScreen) realtimeScreen = createRealtimeScreen({\\n    host: document.body, imageBase: BASE,\\n    api: async (path, body) => {\\n      const controller = new AbortController(), timer = setTimeout(() => controller.abort(), 12000);\\n      const headers = { 'x-gmm': '1', ...(APP && APP.token() ? { 'x-gmm-app': '1', 'x-gmm-s': APP.token() } : {}) };\\n      try {\\n        const response = await fetch(`${BASE}/my/api/${path}`, { signal: controller.signal, cache: 'no-store', headers: body === undefined ? headers : {...headers, 'content-type':'application/json'}, ...(body === undefined ? {} : {method:'POST', body:JSON.stringify(body)}) });\\n        const json = await response.json();\\n        if (!response.ok) { const error = new Error(json.error || `오류(${response.status})`); error.status = response.status; throw error; }\\n        return json;\\n      } finally { clearTimeout(timer); }\\n    },\\n    confirmLeave: text => ask(text, {ok:'항복',danger:true}),\\n    onExit: modeScreen,\\n  });\\n  return realtimeScreen;\\n}\\nasync function pvpStart(mode) {\\n  modal.hidden = true;\\n  getRealtimeScreen().start(mode);\\n}\\n\"],[\"    titleScreen(!!ACC);\",\"    titleScreen(!!ACC);\\n    if (ACC) { try { await getRealtimeScreen().restore(); } catch { /* Available again on the next PvP start; never substitute AI. */ } }\"],[\"if (ACC) myApi('pvp').then(d => {\",\"if (ACC) myApi('pvp/rank').then(d => {\"],[\"let d; try { d = await myApi('pvp'); }\",\"let d; try { d = await myApi('pvp/rank'); }\"],[\"다른 수비대의 「전투 편성」 팀과 대결 · 모두 같은 레벨\",\"실제 유저와 동시에 선택 · 모두 같은 레벨\"],[\"<b class=\\\"tier\\\">${esc(d.me.tier)}</b>\",\"<b class=\\\"tier\\\">${esc(d.me.tier)}${d.me.promotion?.active ? ` · 승급전 ${d.me.promotion.wins}승 ${d.me.promotion.losses}패` : ''}</b>\"]]")

def prepare(root:Path,payloadRoot:Path)->dict[Path,str]:
    """Validate every web target, returning absolute paths and replacement contents.
    Import-safe; no writes. Existing unrelated augment UI edits are preserved.
    """
    root=Path(root).resolve()
    payloadRoot=Path(payloadRoot).resolve()
    project=root/'galmaegiman-confirmed'
    baseline=subprocess.run(['git','-C',str(root),'show',BASE+':galmaegiman-confirmed/'+PATH],check=True,capture_output=True).stdout
    blob=hashlib.sha1(b'blob '+str(len(baseline)).encode()+b'\0'+baseline).hexdigest()
    if blob!=EXPECTED: raise ValueError('Refusing mismatched baseline git object.')
    target=project/PATH
    if target.is_symlink():raise ValueError('Refusing symlink target '+str(target))
    new=target.read_text(encoding='utf-8')
    for before,after in EDITS:
        if new.count(before)!=1: raise ValueError('Ambiguous/missing web anchor; no output written.')
        new=new.replace(before,after,1)
    outputs={target:new}
    for name,dest in [('realtime-ranked-client.js','public/duel/realtime-ranked-client.js'),('realtime-ranked-screen.js','public/duel/realtime-ranked-screen.js'),('realtime-ranked-client.test.ts','test/realtime-ranked-client.test.ts')]:
        target=project/dest
        if target.exists() or target.is_symlink():raise ValueError('Refusing existing target '+str(target))
        outputs[target]=(payloadRoot/name).read_text(encoding='utf-8')
    return outputs

def main():
    if len(sys.argv)!=2:raise SystemExit('Usage: python3 emit-realtime-web-patch.py /path/to/repo > web.patch')
    root=Path(sys.argv[1]).resolve()
    outputs=prepare(root,Path(__file__).resolve().parent)
    patch=[]
    for target,after in outputs.items():
        before=target.read_text(encoding='utf-8') if target.exists() else ''
        relative=target.relative_to(root).as_posix()
        patch.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+relative if target.exists() else '/dev/null',tofile='b/'+relative))
    sys.stdout.write(''.join(patch))

if __name__=='__main__':main()

