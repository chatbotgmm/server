package org.dpdns.gmm;

import static org.junit.Assert.*;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;
import org.robolectric.annotation.LooperMode;

/** Manual draft regression tests; not executed. All transport callbacks are controlled. */
@RunWith(RobolectricTestRunner.class)
@Config(sdk = 35, qualifiers = "w915dp-h412dp-land-mdpi")
@LooperMode(LooperMode.Mode.PAUSED)
public class NativeRealtimeTest {
  final NativeGameFlowTest fixtures = new NativeGameFlowTest();
  @Before public void isolate() {
    fixtures.isolate();
    org.robolectric.RuntimeEnvironment.getApplication().getSharedPreferences("native_realtime", 0).edit().clear().commit();
  }

  static final class Request {
    final String path; final JSONObject body; final NativeApi.Result callback;
    Request(String p, JSONObject b, NativeApi.Result c) { path = p; body = b; callback = c; }
    void ok(JSONObject value) { callback.done(value, null); }
    void fail() { callback.done(null, "연결하지 못했어요."); }
  }
  static final class FakeApi extends NativeApi {
    final MainActivity h;
    final List<Request> requests = new ArrayList<>();
    FakeApi(MainActivity activity) { super(activity); h = activity; }
    @Override String token() { return "realtime-test-account"; }
    @Override void call(String path, JSONObject body, Result callback) {
      if (path.equals("native/state")) { callback.done(h.state, null); return; }
      requests.add(new Request(path, body, callback));
    }
    Request last(String path) {
      for (int i = requests.size() - 1; i >= 0; i--) if (requests.get(i).path.equals(path)) return requests.get(i);
      throw new AssertionError("Missing request: " + path);
    }
    long count(String path) { return requests.stream().filter(r -> r.path.equals(path)).count(); }
  }
  FakeApi install(MainActivity h) {
    if (h.realtime != null) h.realtime.close();
    h.getSharedPreferences("native_realtime", 0).edit().clear().commit();
    h.api.close(); FakeApi api = new FakeApi(h); h.api = api;
    h.art.key = "local-review";
    h.realtime = new NativeRealtime(h); h.realtime.resumed = true;
    return api;
  }
  JSONObject attempt() { return MainActivity.obj("attemptId", "attempt-1", "token", "opaque-test-token",
      "joinNotAfter", 9999999999999L, "serverNow", 1000); }

  @Test public void cancelDuringInertPrepareNeverJoinsAfterLateResponse() {
    try (var activity = fixtures.start()) {
      MainActivity h = activity.get(); FakeApi api = install(h);
      h.realtime.begin("rank"); api.last("pvp/queue/current").ok(MainActivity.obj("status", "idle"));
      Request prepare = api.last("pvp/queue/attempt");
      assertFalse(h.busy);
      h.realtime.cancel(); prepare.ok(attempt());
      assertEquals(0, api.count("pvp/queue/join"));
      assertEquals(0, api.count("pvp/queue/cancel"));
      assertFalse(h.realtime.cancelling);
    }
  }
  @Test public void cancelDuringJoinHonoursMatchedRaceWithoutSurrender() {
    try (var activity = fixtures.start()) {
      MainActivity h = activity.get(); FakeApi api = install(h);
      h.realtime.begin("rank"); api.last("pvp/queue/current").ok(MainActivity.obj("status", "idle"));
      api.last("pvp/queue/attempt").ok(attempt());
      Request join = api.last("pvp/queue/join");
      h.realtime.cancel(); Request cancel = api.last("pvp/queue/cancel");
      join.ok(MainActivity.obj("status", "waiting", "attemptId", "attempt-1"));
      assertTrue(h.realtime.cancelling);
      cancel.ok(MainActivity.obj("status", "matched", "roomId", "room-1"));
      assertEquals("room-1", h.realtime.room);
      assertEquals(1, api.count("pvp/room/current?roomId=room-1"));
      assertEquals(0, api.count("pvp/room/surrender"));
    }
  }
  @Test public void unknownCancelRetriesSameRequestIdentity() {
    try (var activity = fixtures.start()) {
      MainActivity h = activity.get(); FakeApi api = install(h);
      h.realtime.begin("rank"); api.last("pvp/queue/current").ok(MainActivity.obj("status", "idle"));
      api.last("pvp/queue/attempt").ok(attempt());
      h.realtime.cancel(); Request first = api.last("pvp/queue/cancel");
      first.fail();
      assertTrue(h.realtime.cancelling); assertEquals("attempt-1", h.realtime.attempt);
      h.realtime.sendCancel(); Request second = api.last("pvp/queue/cancel");
      assertEquals(first.body.optString("requestId"), second.body.optString("requestId"));
      assertEquals(2, api.count("pvp/queue/cancel"));
    }
  }
  @Test public void staleRenderedPhaseCannotSubmitToNewTurn() {
    try (var activity = fixtures.start()) {
      MainActivity h = activity.get(); FakeApi api = install(h); h.realtime.loadSaved();
      h.realtime.room = "room-1";
      h.realtime.latest = MainActivity.obj("phaseId", "room-1:2", "canSubmit", true);
      JSONObject old = MainActivity.obj("realtime", true, "session", "room-1", "phaseId", "room-1:1");
      h.realtime.submit(old, MainActivity.obj("action", MainActivity.obj("kind", "skill", "skillId", "basic")));
      assertEquals(0, api.count("pvp/room/command"));
      assertEquals(1, api.count("pvp/room/current?roomId=room-1"));
    }
  }
  @Test public void noPollCanOvertakePendingJoin() {
    try (var activity = fixtures.start()) {
      MainActivity h = activity.get(); FakeApi api = install(h);
      h.realtime.begin("rank"); api.last("pvp/queue/current").ok(MainActivity.obj("status", "idle"));
      api.last("pvp/queue/attempt").ok(attempt());
      h.realtime.refresh();
      assertEquals(1, api.count("pvp/queue/current"));
    }
  }
  @Test public void cancellationDuringRecoveryWaitsForServerAcknowledgment() {
    try (var activity = fixtures.start()) {
      MainActivity h = activity.get(); FakeApi api = install(h);
      h.realtime.begin("rank"); h.realtime.cancel();
      assertTrue(h.realtime.cancelling);
      api.last("pvp/queue/current").ok(MainActivity.obj("status", "waiting",
          "attemptId", "attempt-1", "token", "opaque-test-token"));
      assertEquals(1, api.count("pvp/queue/cancel"));
      assertEquals(0, api.count("pvp/queue/attempt"));
    }
  }
  @Test public void idleAfterUncertainJoinMustTombstoneKnownAttempt() {
    try (var activity = fixtures.start()) {
      MainActivity h = activity.get(); FakeApi api = install(h);
      h.realtime.begin("rank"); api.last("pvp/queue/current").ok(MainActivity.obj("status", "idle"));
      api.last("pvp/queue/attempt").ok(attempt());
      api.last("pvp/queue/join").fail(); h.realtime.refresh();
      api.last("pvp/queue/current").ok(MainActivity.obj("status", "idle"));
      assertTrue(h.realtime.cancelling);
      assertEquals("attempt-1", api.last("pvp/queue/cancel").body.optString("attemptId"));
    }
  }
  @Test public void transportBusyDoesNotPersistDisabledSnapshot() {
    try (var activity = fixtures.start()) {
      MainActivity h = activity.get(); install(h); h.realtime.room = "room-1";
      h.realtime.writing = true;
      JSONObject b = h.realtime.decorate(MainActivity.obj("battle", new JSONObject(),
          "canSubmit", true, "phaseId", "room-1:1"));
      assertTrue(b.optBoolean("canSubmit"));
    }
  }
}
