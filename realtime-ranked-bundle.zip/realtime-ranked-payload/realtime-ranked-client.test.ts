// MANUAL DRAFT: not executed. Run in the project's Vitest environment after review.
import {afterEach,beforeEach,describe,expect,it,vi} from 'vitest';
// @ts-ignore The browser controller intentionally remains an unbundled JS module.
import {RealtimeRankedClient} from '../public/duel/realtime-ranked-client.js';

const deferred=()=>{let resolve!:(v:any)=>void,reject!:(e:any)=>void;const promise=new Promise<any>((a,b)=>{resolve=a;reject=b;});return {promise,resolve,reject};};
const room=(patch:any={})=>({roomId:'r1',mode:'rank',phaseId:'r1:1',revision:1,deadline:31000,serverNow:1000,canSubmit:true,mySubmitted:false,opponentReady:false,result:null,battle:{phase:'action'},...patch});
function fixture(api:any){let seq=0;const changes:any[]=[];const client=new RealtimeRankedClient({api,onChange:(s:any)=>changes.push(s),now:()=>1000,uuid:()=>`request-${++seq}`,storage:{getItem:()=>null,setItem:()=>{},removeItem:()=>{}}});return {client,changes};}
beforeEach(()=>vi.useFakeTimers());
afterEach(()=>{vi.clearAllTimers();vi.useRealTimers();});

describe('realtime human matchmaking client',()=>{
  it('cancels while attempt creation is pending and never joins afterward',async()=>{
    const attempt=deferred();const api=vi.fn(async(path:string,_body?:any)=>{
      if(path==='pvp/queue/current')return {status:'idle'};
      if(path==='pvp/queue/attempt')return attempt.promise;
      if(path==='pvp/queue/cancel')return {status:'cancelled'};
      throw new Error(path);
    });const {client}=fixture(api);const start=client.start('rank');await vi.advanceTimersByTimeAsync(0);client.cancel();
    expect(client.state.status).toBe('cancelling');
    attempt.resolve({attemptId:'a',token:'t'});await start;
    expect(api.mock.calls.map(x=>x[0])).toEqual(['pvp/queue/current','pvp/queue/attempt','pvp/queue/cancel']);
    expect(client.state.status).toBe('cancelled');
  });
  it('does not report cancellation before server acknowledgement',async()=>{
    const cancel=deferred();const api=vi.fn(async(path:string,_body?:any)=>path==='pvp/queue/current'?{status:'idle'}:path==='pvp/queue/attempt'?{attemptId:'a',token:'t'}:path==='pvp/queue/join'?{status:'waiting'}:cancel.promise);
    const {client}=fixture(api);await client.start();client.cancel();
    expect(client.state.status).toBe('cancelling');expect(client.dismiss()).toBe(false);
    cancel.resolve({status:'cancelled'});await vi.advanceTimersByTimeAsync(0);
    expect(client.state.status).toBe('cancelled');
  });
  it('enters a matched room when cancel loses the race, without surrendering',async()=>{
    const api=vi.fn(async(path:string,_body?:any)=>{
      if(path==='pvp/queue/current')return {status:'idle'};
      if(path==='pvp/queue/attempt')return {attemptId:'a',token:'t'};
      if(path==='pvp/queue/join')return {status:'waiting'};
      if(path==='pvp/queue/cancel')return {status:'matched',roomId:'r1'};
      if(path.startsWith('pvp/room/current'))return room();throw new Error(path);
    });const {client}=fixture(api);await client.start();client.cancelWanted=true;await client.cancelRequest();
    expect(client.state.room.roomId).toBe('r1');expect(api.mock.calls.some(x=>x[0].includes('surrender'))).toBe(false);
  });
  it('does not let a delayed waiting response resurrect cancelled queue state',async()=>{
    const {client}=fixture(vi.fn());client.state.status='cancelled';await client.acceptQueue({status:'waiting'});
    expect(client.state.status).toBe('cancelled');
  });
  it('retries an uncertain action with exactly the same request ID and payload',async()=>{
    let fail=true;const api=vi.fn(async(path:string,_body?:any)=>{
      if(path==='pvp/room/command'){if(fail){fail=false;throw new Error('offline');}return room({mySubmitted:true,canSubmit:false,revision:2});}
      return room();
    });const {client}=fixture(api);client.acceptRoom(room());
    await client.submit({action:{kind:'skill',skillId:'basic'}});const pending=client.pendingCommand;
    expect(pending).not.toBeNull();await client.retryCommand();
    expect(api.mock.calls.filter(x=>x[0]==='pvp/room/command').map(x=>x[1])).toEqual([pending,pending]);
    expect(client.state.pending).toBe(false);
  });
  it('clears a successful same-phase reroll without extending server deadline',async()=>{
    const api=vi.fn(async(_path:string,_body?:any)=>room({revision:2}));const {client}=fixture(api);client.acceptRoom(room());
    await client.submit({reroll:0});expect(client.pendingCommand).toBeNull();
    expect(client.state.room.deadline).toBe(31000);expect(client.seconds()).toBe(30);
  });
  it('discards old revisions and never performs local timeout actions',async()=>{
    const api=vi.fn();const {client}=fixture(api);client.acceptRoom(room({revision:7,deadline:500}));
    client.acceptRoom(room({revision:6,deadline:99000}));
    expect(client.state.room.revision).toBe(7);expect(client.seconds()).toBe(0);expect(api).not.toHaveBeenCalled();
  });
  it('rejects duplicate click submissions while a request is in flight',async()=>{
    const response=deferred(),api=vi.fn((_path:string,_body?:any)=>response.promise);const {client}=fixture(api);client.acceptRoom(room());
    const a=client.submit({action:{kind:'skill',skillId:'first'}});await client.submit({action:{kind:'skill',skillId:'second'}});
    expect(api).toHaveBeenCalledTimes(1);response.resolve(room({mySubmitted:true,canSubmit:false,revision:2}));await a;
  });
  it('restores a matched room through authoritative queue/current after reload',async()=>{
    const api=vi.fn(async(path:string,_body?:any)=>path==='pvp/queue/current'?{status:'matched',roomId:'r1'}:room());
    const {client}=fixture(api);await client.recover();expect(client.state.room.roomId).toBe('r1');
    expect(api.mock.calls.some(x=>x[0]==='pvp/queue/join')).toBe(false);
  });
  it('tombstones a known uncertain join before accepting idle',async()=>{
    const cancelled=deferred();const api=vi.fn((_path:string,_body?:any)=>cancelled.promise);const {client}=fixture(api);
    client.attempt={attemptId:'known',token:'token'};client.cancelId='cancel-once';client.state.status='joining';
    const reconcile=client.acceptQueue({status:'idle'});
    expect(client.state.status).toBe('cancelling');expect(client.attempt.attemptId).toBe('known');
    expect(api).toHaveBeenCalledWith('pvp/queue/cancel',{attemptId:'known',token:'token',requestId:'cancel-once'});
    cancelled.resolve({status:'cancelled',attemptId:'known'});await reconcile;
    expect(client.attempt).toBeNull();expect(client.state.status).toBe('cancelled');
  });
  it('honors cancellation during preflight without creating an attempt',async()=>{
    const current=deferred(),api=vi.fn((_path:string,_body?:any)=>current.promise);const {client}=fixture(api);
    const start=client.start();client.cancel();current.resolve({status:'idle'});await start;
    expect(api.mock.calls.map(x=>x[0])).toEqual(['pvp/queue/current']);expect(client.state.status).toBe('cancelled');
  });
  it('start resumes an existing room instead of creating an attempt',async()=>{
    const api=vi.fn(async(path:string,_body?:any)=>path==='pvp/queue/current'?{status:'matched',roomId:'r1'}:room());
    const {client}=fixture(api);await client.start();expect(client.state.room.roomId).toBe('r1');
    expect(api.mock.calls.some(x=>x[0]==='pvp/queue/attempt')).toBe(false);
  });
  it('does not apply another attempt cancellation marker after account switch',async()=>{
    const api=vi.fn(async(_path:string,_body?:any)=>({status:'waiting',attemptId:'account-B-attempt',token:'B'}));
    const {client}=fixture(api);client.storage={getItem:()=> 'account-A-attempt',setItem:()=>{},removeItem:()=>{}};
    await client.recover();expect(client.cancelWanted).toBe(false);
    expect(api.mock.calls.some(x=>x[0]==='pvp/queue/cancel')).toBe(false);
  });
  it.each(['command','surrender'])('ignores stale %s responses after generation change',async(kind)=>{
    const response=deferred(),api=vi.fn((_path:string,_body?:any)=>response.promise);const {client}=fixture(api);client.acceptRoom(room());
    const pending=kind==='command'?client.submit({action:{kind:'skill',skillId:'basic'}}):client.surrender();
    client.generation++;client.state={status:'preparing',room:null,error:null,pending:false};
    response.resolve(room({revision:2,result:{winner:0,settlement:'settled'}}));await pending;
    expect(client.state.status).toBe('preparing');expect(client.state.room).toBeNull();
  });
  it('keeps preparation lineup authoritative until the server acknowledges draft save',async()=>{
    const response=deferred(),api=vi.fn((_path:string,_body?:any)=>response.promise);const {client}=fixture(api);
    const preparation={selectedIds:['D1','D2','D3'],ready:false,opponentReady:false,available:[]};
    client.acceptRoom(room({phase:'prepare',battle:null,preparation}));
    const save=client.submit({prepare:{team:['D1','D2','D4'],ready:false}});
    expect(client.state.room.preparation.selectedIds).toEqual(['D1','D2','D3']);
    expect(client.state.pending).toBe(true);
    response.resolve(room({phase:'prepare',battle:null,revision:2,preparation:{...preparation,selectedIds:['D1','D2','D4']}}));await save;
    expect(client.state.room.preparation.selectedIds).toEqual(['D1','D2','D4']);expect(client.state.pending).toBe(false);
  });
  it('prevents simultaneous draft and ready requests from overwriting each other',async()=>{
    const response=deferred(),api=vi.fn((_path:string,_body?:any)=>response.promise);const {client}=fixture(api);
    client.acceptRoom(room({phase:'prepare',battle:null,preparation:{selectedIds:['D1','D2','D3'],ready:false}}));
    const save=client.submit({prepare:{team:['D1','D2','D4'],ready:false}});
    await client.submit({prepare:{team:['D1','D2','D4'],ready:true}});
    expect(api).toHaveBeenCalledTimes(1);
    response.resolve(room({phase:'prepare',battle:null,revision:2,preparation:{selectedIds:['D1','D2','D4'],ready:false}}));await save;
  });
  it('waits for the server to advance preparation and adopts the new augment deadline',async()=>{
    const api=vi.fn(async(_path:string,_body?:any)=>room({phase:'choose',phaseId:'r1:choose1',revision:3,deadline:61000,battle:{phase:'choose'},preparation:null}));
    const {client}=fixture(api);client.acceptRoom(room({phase:'prepare',battle:null,preparation:{selectedIds:['D1','D2','D3'],ready:false}}));
    await client.submit({prepare:{team:['D1','D2','D3'],ready:true}});
    expect(client.state.room.phase).toBe('choose');expect(client.state.room.phaseId).toBe('r1:choose1');expect(client.state.room.deadline).toBe(61000);
  });
  it('preparation timeout never chooses a local lineup or advances the phase',()=>{
    const api=vi.fn(),{client}=fixture(api);client.acceptRoom(room({phase:'prepare',deadline:500,battle:null,preparation:{selectedIds:['D1','D2','D3'],ready:false}}));
    expect(client.seconds()).toBe(0);expect(client.state.room.phase).toBe('prepare');expect(api).not.toHaveBeenCalled();
  });
  it('never optimistically decrements item stock before authoritative escrow acknowledgement',async()=>{
    const response=deferred(),api=vi.fn((_path:string,_body?:any)=>response.promise);const {client}=fixture(api);
    client.acceptRoom(room({phase:'action',battle:{phase:'action',inventory:[{id:'potion',count:2}]}}));
    const use=client.submit({action:{kind:'item',item:'potion'}});
    expect(client.state.room.battle.inventory[0].count).toBe(2);
    response.resolve(room({phase:'action',revision:2,mySubmitted:true,canSubmit:false,battle:{phase:'action',inventory:[{id:'potion',count:1}]}}));await use;
    expect(client.state.room.battle.inventory[0].count).toBe(1);
    expect(api.mock.calls[0][1].command).toEqual({action:{kind:'item',item:'potion'}});
  });
  it('retries feather with the same request ID and explicit dead-slot target',async()=>{
    let first=true;const api=vi.fn(async(_path:string,_body?:any)=>{if(first){first=false;throw new Error('offline');}return room({revision:2,mySubmitted:true,canSubmit:false});});
    const {client}=fixture(api);client.acceptRoom(room());await client.submit({action:{kind:'item',item:'feather',target:2}});
    await client.retryCommand();expect(api).toHaveBeenCalledTimes(2);expect(api.mock.calls[0][1]).toEqual(api.mock.calls[1][1]);
    expect(api.mock.calls[1][1].command.action.target).toBe(2);
  });
});
