#!/usr/bin/env python3
"""Manual draft. Defaults to validation only; --apply writes in the user's checkout.
Keep NativeRealtime.java beside this generator. Run AFTER approved augment generators.
Does not build, push, deploy, migrate, or execute application code.
"""
from pathlib import Path
import argparse
import shutil

def once(text, old, new):
    count = text.count(old)
    if count != 1: raise SystemExit('Expected one anchor, found %d: %s' % (count, old[:100]))
    return text.replace(old, new, 1)

def prepare(root: Path, payloadRoot: Path) -> dict[Path, str]:
    """Validate all inputs and return proposed contents; never write anything.

    root contains galmaegiman-confirmed; payloadRoot contains the two Java files.
    Importing this module performs no filesystem reads or writes.
    """
    JAVA = root / 'galmaegiman-confirmed/app/android/app/src/main/java/org/dpdns/gmm'
    outputs: dict[Path, str] = {}

    def source(name):
        path = JAVA / (name + '.java')
        if path.is_symlink(): raise SystemExit('Refusing symlink: ' + str(path))
        return path, path.read_text(encoding='utf-8')

    p, s = source('MainActivity')
    if 'realtime-native-v1' in s: raise SystemExit('Realtime native patch already present')
    s = once(s, '  JSONObject state = new JSONObject(), battle;',
    '  // realtime-native-v1\n  NativeRealtime realtime;\n  JSONObject state = new JSONObject(), battle;')
    s = once(s, '    api = new NativeApi(this);', '    api = new NativeApi(this);\n    realtime = new NativeRealtime(this);')
    s = once(s, '  void stateUpdated() {', '  void stateUpdated() {\n    if (realtime != null) realtime.recover();')
    s = once(s, '  void startFight(String mode, String stage) {', '''  void startFight(String mode, String stage) {
    if (mode.equals("normal") || mode.equals("rank")) {
      realtime.begin(mode);
      return;
    }''')
    s = once(s, '  void battleTurn(JSONObject event) {', '''  void battleTurnFrom(JSONObject shown, JSONObject event) {
    if (NativeRealtime.isBattle(shown)) realtime.submit(shown, event);
    else battleTurn(event);
  }

  void battleTurn(JSONObject event) {
    if (NativeRealtime.isBattle(battle)) { realtime.submit(battle, event); return; }''')
    s = once(s, '  void refreshProgress(String current) {', '''  void refreshProgress(String current) {
    if (NativeRealtime.isBattle(battle) || current.equals("realtimeQueue")) {
      realtime.refresh(); return;
    }''')
    s = once(s, '  void back() {', '  void back() {\n    if (realtime != null && realtime.back()) return;')
    s = once(s, '    super.onResume();', '    super.onResume();\n    if (realtime != null) realtime.resume();')
    s = once(s, '  protected void onPause() {', '  protected void onPause() {\n    if (realtime != null) realtime.pause();')
    s = once(s, '  protected void onDestroy() {', '  protected void onDestroy() {\n    if (realtime != null) realtime.close();')
    outputs[p] = s

# Bind clicks to the snapshot that rendered their control, not a newly polled turn.
    for name, prefix, snapshot in [
    ('NativeBattleSheets', 'h.battleTurn(', 'v.battle'),
    ('SkillCardView', 'h.battleTurn(', 'view.battle'),
    ('NativeAugmentView', 'h.battleTurn(', 'battleView.battle'),
    ('BattleView', 'host.battleTurn(', 'battle')]:
        p, s = source(name)
        if 'battleTurnFrom(' in s: raise SystemExit('Already integrated: ' + name)
        if prefix not in s: raise SystemExit('Missing click bridge: ' + name)
        s = s.replace(prefix, prefix.replace('battleTurn(', 'battleTurnFrom(') + snapshot + ', ')
        if name == 'NativeAugmentView':
            s = once(s, '          if (remaining <= 0 && !h.busy && !refreshing) {', '''          if (remaining <= 0 && NativeRealtime.isBattle(battleView.battle)) {
            h.realtime.refresh();
            postDelayed(this, 1000);
            return;
          }
          if (remaining <= 0 && !h.busy && !refreshing) {''')
        if name == 'BattleView':
            s = once(s, '랭크게임에서 나갈까요? 패배로 처리되며 랭크 점수가 차감돼요.',
            '랭크게임에서 나갈까요? 패배로 기록되며 랭크 결과에 반영돼요.')
            s = once(s, '    if (phase.equals("choose")) {', '''    if (NativeRealtime.isBattle(battle) && !battle.optBoolean("canSubmit")
        && !phase.equals("over")) {
      controls.addView(host.text("선택 완료 · 상대를 기다리고 있어요", 20));
      controls.addView(host.button("나가기", this::confirmLeave));
      return;
    }
    if (phase.equals("choose")) {''')
            s = once(s, '                  else if (ix == 1) NativeBattleSheets.items(this);', '''                  else if (ix == 1) {
                    if (NativeRealtime.isBattle(battle)) host.message("실시간 PvP에서는 아이템을 사용하지 않아요.");
                    else NativeBattleSheets.items(this);
                  }''')
        outputs[p] = s

# Replace only network endpoint lines; navigation screen IDs remain "pvp".
    for name in ['NativeMenus', 'NativeExtras']:
        p, s = source(name)
        old = '        "pvp",'
        if old not in s: raise SystemExit('Missing rank endpoint in ' + name)
        s = s.replace(old, '        "pvp/rank",')
        if name == 'NativeMenus':
            s = once(s, '랭크는 중간에 나가도 패배와 점수 차감이 적용돼요. 시작할까요?',
            '실제 유저와 실시간으로 대전해요. 매칭 후 나가면 패배로 기록돼요. 시작할까요?')
        outputs[p] = s

    controller = JAVA / 'NativeRealtime.java'
    if controller.exists() or controller.is_symlink(): raise SystemExit('Refusing overwrite: ' + str(controller))
    outputs[controller] = (payloadRoot / 'NativeRealtime.java').read_text(encoding='utf-8')
    test = root / 'galmaegiman-confirmed/app/android/app/src/test/java/org/dpdns/gmm/NativeRealtimeTest.java'
    if test.exists() or test.is_symlink(): raise SystemExit('Refusing overwrite: ' + str(test))
    outputs[test] = (payloadRoot / 'NativeRealtimeTest.java').read_text(encoding='utf-8')
    return outputs


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True,
                        help='Checkout directory containing galmaegiman-confirmed')
    parser.add_argument('--apply', action='store_true',
                        help='Write validated changes; otherwise validate only')
    args = parser.parse_args()
    root = args.root.resolve()
    outputs = prepare(root, Path(__file__).resolve().parent)
    # Preflight every destination and backup BEFORE creating directories or files.
    for path in outputs:
        if path.is_symlink() or not path.resolve().is_relative_to(root):
            raise SystemExit('Unsafe destination: ' + str(path))
        backup = path.with_name(path.name + '.realtime-native.bak')
        if path.exists() and (backup.exists() or backup.is_symlink()):
            raise SystemExit('Backup already exists: ' + str(backup))
    if not args.apply:
        print('Validated %d outputs; no files written. Use --apply to write.' % len(outputs))
        return
    # All source reads and anchor checks succeeded. Preserve originals first.
    for path in outputs:
        if path.exists():
            shutil.copy2(path, path.with_name(path.name + '.realtime-native.bak'))
    for path, text in outputs.items():
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding='utf-8')
    print('Wrote %d outputs; existing files have .realtime-native.bak backups.' % len(outputs))


if __name__ == '__main__':
    main()

