#!/usr/bin/env python3
"""Manual source generator. Default dry-run. No builds, tests, DB changes or deployment.
Run AFTER the existing parchment, augment-layout and augment-switch generators.
Keep realtime-ranked-payload beside this file; commit both to the manual branch.
"""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess

BASE = '838f7ebd1d0617fd73f69bfcf6870a2cd463eaf2'
HERE = Path(__file__).resolve().parent

def blob(data):
    return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()

def load_helper(path, name):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def prepare(root, payload):
    subprocess.run(['git','-C',str(root),'merge-base','--is-ancestor',BASE,'HEAD'],check=True)
    manifest=json.loads((payload/'manifest.json').read_text(encoding='utf-8'))
    project=root/'galmaegiman-confirmed'
    outputs={}
    for relative, expected in manifest['expected'].items():
        path=project/relative
        if path.is_symlink():raise ValueError('Refusing symlink '+str(path))
        raw=path.read_bytes()
        if blob(raw)!=expected:raise ValueError('Source differs from reviewed input: '+relative)
        text=raw.decode('utf-8')
        for old,new in manifest['edits'].get(relative,[]):
            if text.count(old)!=1:raise ValueError('Anchor mismatch: '+relative+' / '+old[:90])
            text=text.replace(old,new,1)
        if relative=='prisma/schema.prisma':text+='\n'+manifest['schemaAppend']
        outputs[path]=text
    for relative, text in manifest['newFiles'].items():
        path=project/relative
        if path.exists() or path.is_symlink():raise ValueError('Refusing overwrite of new target '+relative)
        outputs[path]=text
    for name in ('apply-realtime-native.py','emit-realtime-web-patch.py'):
        helper=load_helper(payload/name,name.replace('-','_').replace('.','_'))
        client=helper.prepare(root,payload)
        if outputs.keys() & client.keys():raise ValueError('Duplicate generated target')
        outputs.update(client)
    for path in outputs:
        if not path.resolve().is_relative_to(project.resolve()):raise ValueError('Target escaped project root')
        if path.is_symlink():raise ValueError('Refusing symlink '+str(path))
        for suffix in ('.realtime-ranked.bak','.realtime-ranked.tmp'):
            if Path(str(path)+suffix).exists():raise ValueError('Refusing overwrite '+str(path)+suffix)
    return outputs

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,default=HERE)
    parser.add_argument('--apply',action='store_true')
    args=parser.parse_args();root=args.root.resolve();payload=HERE/'realtime-ranked-payload'
    outputs=prepare(root,payload)
    originals={p:p.read_bytes() for p in outputs if p.exists()}
    for path in outputs:print(('WRITE ' if args.apply else 'CHECK ')+str(path.relative_to(root)))
    if not args.apply:
        print('All source and client anchors prepared. No writes, tests, migration or deployment.')
        return
    try:
        # Recheck all originals before the first source write.
        for path,data in originals.items():
            if path.read_bytes()!=data:raise RuntimeError('Source changed during preparation')
        for path,data in originals.items():
            with Path(str(path)+'.realtime-ranked.bak').open('xb') as out:out.write(data)
        for path,text in outputs.items():
            path.parent.mkdir(parents=True,exist_ok=True)
            if path in originals:
                temp=Path(str(path)+'.realtime-ranked.tmp')
                with temp.open('x',encoding='utf-8',newline='\n') as out:out.write(text)
                os.replace(temp,path)
            else:
                with path.open('x',encoding='utf-8',newline='\n') as out:out.write(text)
    except Exception:
        print('Interrupted: some draft files may be written. Backups retained. Do not deploy.')
        raise
    print('Draft source applied in this checkout. Tests, DB migration and deployment were NOT run.')

if __name__=='__main__':main()
